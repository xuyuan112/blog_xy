import Key from "../i18nKey";
import type { Translation } from "../translation";

export const ru: Translation = {
	[Key.home]: "Главная",
	[Key.about]: "О нас",
	[Key.archive]: "Архив",
	[Key.search]: "Поиск",
	[Key.searchNoResults]: "Результаты не найдены.",
	[Key.searchTypeSomething]: "Введите ключевое слово для поиска...",
	[Key.searchLoading]: "Поиск...",
	[Key.searchSummary]: "Резюме",
	[Key.searchContent]: "Содержание",
	[Key.searchViewMore]: "Показать еще ({count} шт)",
	[Key.other]: "Прочее",

	// Группы меню навигации
	[Key.navArticles]: "Статьи",
	[Key.navSocial]: "Соцсети",
	[Key.navMine]: "Моё",
	[Key.navAbout]: "Обо мне",
	[Key.navLinks]: "Ссылки",
	[Key.all]: "Все",

	[Key.tags]: "Теги",
	[Key.categories]: "Категории",
	[Key.allCategories]: "Все категории",
	[Key.allTags]: "Все теги",
	[Key.allSeries]: "Все серии",
	[Key.recentPosts]: "Последние посты",
	[Key.postList]: "Список постов",
	[Key.tableOfContents]: "Содержание",
	[Key.tocEmpty]: "На этой странице нет оглавления",
	[Key.music]: "Музыка",
	[Key.dynamic]: "Моменты",
	[Key.latestDynamics]: "Последние публикации",
	[Key.moreDynamics]: "Больше публикаций",
	[Key.dynamicDescription]: "Короткие мысли и моменты повседневной жизни.",
	[Key.dynamicEmpty]: "Пока нет публикаций",
	[Key.dynamicSearch]: "Поиск публикаций...",
	[Key.dynamicNoResults]: "Подходящие публикации не найдены",
	[Key.dynamicLoading]: "Загрузка публикаций",
	[Key.dynamicAllYears]: "Все годы",
	[Key.dynamicLoadMore]: "Загрузить ещё",
	[Key.dynamicBackToList]: "Назад к публикациям",
	[Key.dynamicProfile]: "Открыть профиль {name}",
	[Key.dynamicPermalink]: "Постоянная ссылка на публикацию",
	[Key.dynamicCollapseGallery]: "Свернуть",
	[Key.dynamicViewOriginal]: "Открыть оригинал",
	[Key.dynamicPreviousImage]: "Предыдущее изображение",
	[Key.dynamicNextImage]: "Следующее изображение",
	[Key.dynamicViewImage]: "Открыть изображение {index}",
	[Key.dynamicSelectImage]: "Выбрать изображение {index}",
	[Key.musicNoPlaying]: "Ничего не воспроизводится",
	[Key.musicLyrics]: "Текст песни",
	[Key.musicVolume]: "Громкость",
	[Key.musicPlayMode]: "Переключить режим воспроизведения",
	[Key.musicPrev]: "Предыдущий трек",
	[Key.musicNext]: "Следующий трек",
	[Key.musicPlaylist]: "Плейлист",
	[Key.musicNoLyrics]: "Текст песни отсутствует",
	[Key.musicLoadingLyrics]: "Загрузка текста песни...",
	[Key.musicFailedLyrics]: "Ошибка загрузки текста песни",
	[Key.musicNoSongs]: "Нет песен",
	[Key.musicError]: "Ошибка плеера",
	[Key.musicPlay]: "Воспроизвести",
	[Key.musicPause]: "Пауза",
	[Key.musicProgress]: "Прогресс воспроизведения",
	[Key.musicCover]: "Обложка",
	[Key.musicNoCover]: "Нет обложки",
	[Key.musicAudioPlayer]: "Аудиоплеер",

	// Объявление
	[Key.announcement]: "Объявление",
	[Key.announcementClose]: "Закрыть",

	[Key.comments]: "Комментарии",
	[Key.commentSection]: "Комментарии",
	[Key.commentSubtitle]: "Поделитесь своими мыслями и обсудите с остальными",
	[Key.commentNotConfigured]: "Система комментариев не настроена",
	[Key.guestbookCommentHint]:
		"Вы еще не включили систему комментариев в файле конфигурации. После включения посетители смогут оставлять сообщения здесь",
	[Key.friends]: "Ссылки",
	[Key.friendsDescription]:
		"Вот мои друзья, добро пожаловать посетить и общаться друг с другом",
	[Key.searchFriends]: "Поиск друзей...",
	[Key.friendsEmpty]: "Друзей пока нет.",
	[Key.booknav]: "Каталог закладок",
	[Key.booknavDescription]:
		"Подборка полезных сайтов, сгруппированных по категориям.",
	[Key.searchBooknav]: "Поиск закладок...",
	[Key.booknavEmpty]: "Закладок пока нет.",
	[Key.guestbook]: "Гостевая книга",
	[Key.guestbookDescription]:
		"Добро пожаловать, оставьте свой след здесь, поделитесь своими мыслями и предложениями",
	[Key.untitled]: "Без названия",
	[Key.uncategorized]: "Без категории",
	[Key.noTags]: "Нет тегов",

	[Key.wordCount]: "слово",
	[Key.wordsCount]: "слова",
	[Key.minuteCount]: "минута",
	[Key.minutesCount]: "минуты",
	[Key.postCount]: "пост",
	[Key.postsCount]: "постов",
	[Key.tagsCount]: "тегов",
	[Key.noData]: "Нет данных",

	[Key.themeColor]: "Цвет темы",

	[Key.lightMode]: "Светлая",
	[Key.darkMode]: "Тёмная",
	[Key.systemMode]: "Система",

	[Key.more]: "Ещё",
	[Key.collapse]: "Свернуть",

	[Key.author]: "Автор",
	[Key.publishedAt]: "Опубликовано",
	[Key.updatedAt]: "Обновлено",
	[Key.readTime]: "Время чтения",
	[Key.license]: "Лицензия",
	[Key.bangumi]: "Bangumi",

	// Фильтр и статус Бангуми текст
	[Key.bangumiTitle]: "Мой Bangumi",
	[Key.bangumiSubtitle]: "Запись моего аниме путешествия",
	[Key.bangumiFilterAll]: "Все",
	[Key.bangumiFilterWatched]: "Просмотрено",
	[Key.bangumiFilterWatching]: "Смотрю",
	[Key.bangumiFilterWish]: "Хочу",
	[Key.bangumiFilterOnHold]: "Отложено",
	[Key.bangumiFilterDropped]: "Брошено",
	[Key.bangumiFilterGamePlayed]: "Пройдено",
	[Key.bangumiFilterGamePlaying]: "Играю",
	[Key.bangumiFilterGameWish]: "Хочу сыграть",
	[Key.bangumiFilterBookRead]: "Прочитано",
	[Key.bangumiFilterBookReading]: "Читаю",
	[Key.bangumiFilterBookWish]: "Хочу прочитать",
	[Key.bangumiFilterMusicListened]: "Прослушано",
	[Key.bangumiFilterMusicListening]: "Слушаю",
	[Key.bangumiFilterMusicWish]: "Хочу послушать",
	[Key.bangumiStatusWish]: "Хочу",
	[Key.bangumiStatusWatched]: "Просмотрено",
	[Key.bangumiStatusWatching]: "Смотрю",
	[Key.bangumiStatusOnHold]: "Отложено",
	[Key.bangumiStatusDropped]: "Брошено",
	[Key.bangumiStatusGameWish]: "Хочу сыграть",
	[Key.bangumiStatusGamePlayed]: "Пройдено",
	[Key.bangumiStatusGamePlaying]: "Играю",
	[Key.bangumiStatusBookWish]: "Хочу прочитать",
	[Key.bangumiStatusBookRead]: "Прочитано",
	[Key.bangumiStatusBookReading]: "Читаю",
	[Key.bangumiStatusMusicWish]: "Хочу послушать",
	[Key.bangumiStatusMusicListened]: "Прослушано",
	[Key.bangumiStatusMusicListening]: "Слушаю",
	[Key.bangumiStatusUnknown]: "Неизвестно",
	[Key.bangumiNoData]: "Нет данных",
	[Key.bangumiNoDataDescription]: "В этой категории нет элементов",
	[Key.bangumiEmpty]: "Нет данных",
	[Key.bangumiEmptyReason]:
		"Возможные причины: имя пользователя не существует, проблема с подключением к сети или ограничение API",
	[Key.bangumiFetchError]: "Ошибка загрузки данных Bangumi",
	[Key.bangumiFetchErrorDesc]:
		"Не удалось загрузить данные из Bangumi API при сборке. Эта страница временно недоступна.",
	[Key.bangumiUsername]: "Имя пользователя",
	[Key.bangumiApi]: "API",
	[Key.bangumiConfigTip]:
		"Подсказка: установите правильное имя пользователя Bangumi в конфигурации страницы",
	[Key.bangumiPrevPage]: "Предыдущая",
	[Key.bangumiNextPage]: "Следующая",
	[Key.bangumiCurrentPage]: "Страница",
	[Key.bangumiTotalPages]: "из",
	[Key.bangumiPage]: "страница",

	// Категории Бангуми
	[Key.bangumiCategoryBook]: "Книга",
	[Key.bangumiCategoryAnime]: "Аниме",
	[Key.bangumiCategoryMusic]: "Музыка",
	[Key.bangumiCategoryGame]: "Игра",
	[Key.bangumiCategoryReal]: "Реальный",

	// Обновление данных Бангуми
	[Key.bangumiLastUpdated]: "Данные обновлены",
	[Key.bangumiUpdatedAt]: "Время сборки",
	[Key.bangumiDataStatic]: "Статические данные",

	// VNDB
	[Key.vndb]: "VNDB",
	[Key.vndbSubtitle]: "Мой список визуальных новелл VNDB",
	[Key.vndbFilterAll]: "Все",
	[Key.vndbFilterVoted]: "Оценено",
	[Key.vndbFilterUnvoted]: "Без оценки",
	[Key.vndbFilterNotes]: "С заметками",
	[Key.vndbStatusWishlist]: "Хочу сыграть",
	[Key.vndbStatusPlaying]: "Играю",
	[Key.vndbStatusFinished]: "Пройдено",
	[Key.vndbStatusStalled]: "Отложено",
	[Key.vndbStatusDropped]: "Брошено",
	[Key.vndbStatusUnknown]: "Неизвестно",
	[Key.vndbNoData]: "Нет данных",
	[Key.vndbNoDataDescription]: "В этой категории нет элементов",
	[Key.vndbEmpty]: "Нет данных",
	[Key.vndbEmptyReason]:
		"Возможные причины: ID пользователя не существует, список закрыт, проблемы с сетью или ограничение API",
	[Key.vndbFetchError]: "Ошибка загрузки данных VNDB",
	[Key.vndbFetchErrorDesc]:
		"Не удалось загрузить данные из VNDB API при сборке. Эта страница временно недоступна.",
	[Key.vndbNotConfigured]: "ID пользователя VNDB не настроен",
	[Key.vndbNotConfiguredDesc]:
		"Укажите ID пользователя VNDB в src/config/siteConfig.ts",
	[Key.vndbLastUpdated]: "Данные обновлены",
	[Key.vndbVotes]: "голосов",
	[Key.vndbLengthVeryShort]: "Очень короткая",
	[Key.vndbLengthShort]: "Короткая",
	[Key.vndbLengthMedium]: "Средняя",
	[Key.vndbLengthLong]: "Длинная",
	[Key.vndbLengthVeryLong]: "Очень длинная",

	// Отслеживание аниме - Bilibili
	[Key.bilibili]: "Bilibili",
	[Key.bilibiliSubtitle]: "Мой список Bilibili (аниме и сериалы)",
	[Key.bilibiliNotConfigured]: "Источник данных Bilibili не настроен",
	[Key.bilibiliNotConfiguredDesc]:
		"Настройте bilibili.uid в src/config/siteConfig.ts",

	// Отслеживание аниме - общие компоненты
	[Key.animeTotal]: "Всего",
	[Key.animeAverageRating]: "Средний рейтинг",
	[Key.animeSearch]: "Поиск аниме...",
	[Key.animeAllTypes]: "Все",
	[Key.animeTV]: "TV Аниме",
	[Key.animeMovie]: "Фильм",
	[Key.animeRatingDesc]: "По рейтингу ↓",
	[Key.animeRatingAsc]: "По рейтингу ↑",
	[Key.animeDateDesc]: "Сначала новые",
	[Key.animeDateAsc]: "Сначала старые",
	[Key.animeNoResults]: "Аниме не найдено",
	[Key.animeLastUpdated]: "Данные обновлены",
	[Key.animeEpStatus]: "Прогресс",
	[Key.animeViewDetails]: "Подробнее",
	[Key.animeBilibiliAvg]: "Bilibili ср.",
	[Key.animeNoOverview]: "Нет описания",
	[Key.animeClose]: "Закрыть",
	[Key.animeSynopsis]: "Описание",
	[Key.animeWatchNow]: "Смотреть",
	[Key.animeAllWithCount]: "Все ({count})",
	[Key.animeTVWithCount]: "ТВ ({count})",
	[Key.animeMovieWithCount]: "Фильм ({count})",
	[Key.animeTypeAnime]: "Аниме",
	[Key.animeTypeMovie]: "Фильм",
	[Key.animeTypeDocumentary]: "Документальный",
	[Key.animeTypeChinese]: "Китайское аниме",
	[Key.animeTypeDrama]: "Сериал",
	[Key.animeTypeConcert]: "Концерт",

	// MyAnimeList
	[Key.mal]: "MyAnimeList",
	[Key.malSubtitle]: "Мои списки аниме и манги из MyAnimeList",
	[Key.malCategoryAnime]: "Аниме",
	[Key.malCategoryManga]: "Манга",
	[Key.malFilterAll]: "Все",
	[Key.malStatusWatching]: "Смотрю",
	[Key.malStatusReading]: "Читаю",
	[Key.malStatusCompleted]: "Просмотрено",
	[Key.malStatusOnHold]: "Отложено",
	[Key.malStatusDropped]: "Брошено",
	[Key.malStatusPlanToWatch]: "Хочу посмотреть",
	[Key.malStatusPlanToRead]: "Хочу прочитать",
	[Key.malNoData]: "Нет данных",
	[Key.malNoDataDescription]: "В этой категории нет элементов",
	[Key.malEmpty]: "Нет данных",
	[Key.malEmptyReason]:
		"Возможные причины: имя пользователя не существует, список закрыт, неверный Client ID или проблема с сетью",
	[Key.malFetchError]: "Ошибка загрузки данных MyAnimeList",
	[Key.malFetchErrorDesc]:
		"Не удалось загрузить данные из MyAnimeList API при сборке. Проверьте имя пользователя и Client ID, а также убедитесь, что список открыт.",
	[Key.malNotConfigured]: "MyAnimeList не настроен",
	[Key.malNotConfiguredDesc]:
		"Укажите имя пользователя и Client ID MyAnimeList в src/config/siteConfig.ts (список должен быть открытым)",
	[Key.malLastUpdated]: "Данные обновлены",
	[Key.malSeasonWinter]: "Зима",
	[Key.malSeasonSpring]: "Весна",
	[Key.malSeasonSummer]: "Лето",
	[Key.malSeasonFall]: "Осень",

	// Пагинация
	[Key.paginationFirst]: "Первая",
	[Key.paginationPrev]: "Предыдущая",
	[Key.paginationNext]: "Следующая",
	[Key.paginationLast]: "Последняя",
	[Key.paginationPage]: "Страница",
	[Key.paginationOf]: "из",
	[Key.paginationTotal]: ", всего",
	[Key.paginationRecords]: " записей",
	[Key.paginationJump]: "Перейти к странице",

	// 404 Страница
	[Key.notFound]: "404",
	[Key.notFoundTitle]: "Страница не найдена",
	[Key.notFoundDescription]:
		"Извините, страница, которую вы посетили, не существует или была перемещена.",
	[Key.backToHome]: "Вернуться на главную",

	// RSS Страница
	[Key.rss]: "RSS лента",
	[Key.rssDescription]: "Подпишитесь, чтобы получать последние обновления",
	[Key.rssSubtitle]:
		"Подписаться через RSS, чтобы сразу получать последние статьи и обновления",
	[Key.rssLink]: "RSS ссылка",
	[Key.rssCopyToReader]: "Скопировать ссылку в ваш RSS читатель",
	[Key.rssCopyLink]: "Скопировать ссылку",
	[Key.rssLatestPosts]: "Последние посты",
	[Key.rssWhatIsRSS]: "Что такое RSS?",
	[Key.rssWhatIsRSSDescription]:
		"RSS (Really Simple Syndication) — стандартный формат для публикации часто обновляемого контента. С RSS вы можете:",
	[Key.rssBenefit1]:
		"Получать последний контент сайта вовремя без ручного посещения",
	[Key.rssBenefit2]: "Управлять подписками на несколько сайтов в одном месте",
	[Key.rssBenefit3]: "Не пропускать важные обновления и статьи",
	[Key.rssBenefit4]: "Наслаждаться чистым чтением без рекламы",
	[Key.rssHowToUse]:
		"Рекомендуется использовать Feedly, Inoreader или другие RSS читатели для подписки на этот сайт.",
	[Key.rssCopied]: "RSS ссылка скопирована в буфер обмена!",
	[Key.rssCopyFailed]:
		"Ошибка копирования, пожалуйста, скопируйте ссылку вручную",

	// Последнее изменение
	[Key.lastModifiedPrefix]: "Последнее обновление: ",
	[Key.lastModifiedOutdated]: "Некоторый контент может быть устаревшим",
	[Key.lastModifiedDaysAgo]: "{days} дней назад",
	[Key.year]: "год",
	[Key.month]: "месяц",
	[Key.day]: "день",
	[Key.hour]: "час",
	[Key.minute]: "минута",
	[Key.second]: "секунда",

	// Статистика просмотров
	[Key.pageViews]: "Просмотры",
	[Key.pageViewsLoading]: "Загрузка...",
	[Key.pageViewsError]: "Статистика недоступна",

	// Закреплено
	[Key.pinned]: "Закреплено",

	// Похожие статьи
	[Key.relatedPosts]: "Похожие статьи",
	[Key.noRelatedPosts]: "Нет похожих статей",

	// Серия статей
	[Key.series]: "Серии",
	[Key.seriesPartOf]: "Часть серии",
	[Key.seriesPart]: "Часть {n}",
	[Key.seriesThisArticle]: "Эта статья",
	[Key.noSeries]: "Пока нет серий",

	// Зашифровано
	[Key.postEncrypted]: "Эта статья зашифрована",

	// Режим обоев
	[Key.wallpaperMode]: "Режим обоев",
	[Key.wallpaperBannerMode]: "Баннер обои",
	[Key.wallpaperFullscreenMode]: "Полноэкранные обои",
	[Key.wallpaperOverlayMode]: "Прозрачный",
	[Key.wallpaperNoneMode]: "Однотонный фон",

	// Настройки обоев
	[Key.wallpaperSettings]: "Настройки обоев",
	[Key.wallpaperTitle]: "Заголовок главных обоев",
	[Key.wallpaperCarousel]: "Карусель обоев",
	[Key.wavesAnimation]: "Анимация волн",
	[Key.gradientTransition]: "Градиентный переход",
	[Key.sakuraEffect]: "Эффект сакуры",
	[Key.effectsSettings]: "Настройки эффектов",
	[Key.overlaySettings]: "Настройки прозрачности",
	[Key.overlayOpacity]: "Прозрачность обоев",
	[Key.overlayBlur]: "Размытие фона",
	[Key.overlayCardOpacity]: "Прозрачность карточек",

	// Вкладки панели настроек
	[Key.settingsTabAppearance]: "Оформление",
	[Key.settingsTabWallpaper]: "Обои",
	[Key.settingsTabEffects]: "Эффекты",

	// Стиль карточек
	[Key.cardSettings]: "Стиль карточек",
	[Key.cardBorder]: "Рамка и тень карточек",
	[Key.cardFollowTheme]: "Карточки跟随主题色",

	// Макет списка сообщений
	[Key.postListLayout]: "Макет списка сообщений",
	[Key.postListLayoutList]: "Список",
	[Key.postListLayoutGrid]: "Сетка",

	// Страница спонсоров
	[Key.sponsor]: "Спонсор",
	[Key.sponsorTitle]: "Поддержать меня",
	[Key.sponsorDescription]:
		"Если мой контент был полезен для вас, добро пожаловать поддержать меня следующими способами. Ваша поддержка - это движущая сила моего постоянного творчества!",
	[Key.sponsorMethods]: "Способы оплаты",
	[Key.sponsorList]: "Спонсоры",
	[Key.sponsorEmpty]: "Пока нет спонсоров",
	[Key.sponsorAmount]: "Сумма",
	[Key.sponsorDate]: "Дата",
	[Key.sponsorMessage]: "Сообщение",
	[Key.sponsorAnonymous]: "Анонимно",
	[Key.scanToSponsor]: "Сканировать для поддержки",
	[Key.sponsorGoTo]: "Перейти к спонсору",
	[Key.sponsorButton]: "Поддержка и Поделиться",
	[Key.sponsorButtonText]:
		"Если эта статья помогла вам, пожалуйста, поделитесь или поддержите!",

	[Key.shareOnSocial]: "Поделиться статьей",
	[Key.shareOnSocialDescription]:
		"Если эта статья помогла вам, пожалуйста, поделитесь ею с другими!",

	// Статистика сайта
	[Key.siteStats]: "Статистика сайта",
	[Key.siteStatsPostCount]: "Статьи",
	[Key.siteStatsDynamicCount]: "Публикации",
	[Key.siteStatsCategoryCount]: "Категории",
	[Key.siteStatsTagCount]: "Теги",
	[Key.siteStatsTotalWords]: "Всего слов",
	[Key.siteStatsRunningDays]: "Дней работы",
	[Key.siteStatsLastUpdate]: "Последняя активность",
	[Key.siteStatsDaysAgo]: "{days} дней назад",
	[Key.siteStatsDays]: "{days} дней",
	[Key.today]: "Сегодня",

	// Информация о сайте
	[Key.siteInfo]: "Информация о сайте",
	[Key.siteInfoBuildTime]: "Время сборки",
	[Key.siteInfoBuildPlatform]: "Платформа сборки",
	[Key.siteInfoBlogVersion]: "Версия блога",
	[Key.siteInfoAstroVersion]: "Astro",
	[Key.siteInfoNodeVersion]: "Node",
	[Key.siteInfoPnpmVersion]: "pnpm",
	[Key.siteInfoSystem]: "Система",
	[Key.siteInfoExpand]: "Показать информацию о сборке",
	[Key.siteInfoCollapse]: "Скрыть информацию о сборке",
	[Key.siteInfoDomain]: "Домен",
	[Key.siteInfoLicense]: "Лицензия",

	// Компонент календаря
	[Key.calendarSunday]: "Вс",
	[Key.calendarMonday]: "Пн",
	[Key.calendarTuesday]: "Вт",
	[Key.calendarWednesday]: "Ср",
	[Key.calendarThursday]: "Чт",
	[Key.calendarFriday]: "Пт",
	[Key.calendarSaturday]: "Сб",
	[Key.calendarJanuary]: "Янв",
	[Key.calendarFebruary]: "Фев",
	[Key.calendarMarch]: "Мар",
	[Key.calendarApril]: "Апр",
	[Key.calendarMay]: "Май",
	[Key.calendarJune]: "Июн",
	[Key.calendarJuly]: "Июл",
	[Key.calendarAugust]: "Авг",
	[Key.calendarSeptember]: "Сен",
	[Key.calendarOctober]: "Окт",
	[Key.calendarNovember]: "Ноя",
	[Key.calendarDecember]: "Дек",
	[Key.calendar]: "Календарь сайта",
	[Key.calendarHeatmapWeek]: "Неделя {week} {month}, {count} записей",
	[Key.advertisement]: "Реклама",

	[Key.shareArticle]: "Поделиться",
	[Key.generatingPoster]: "Создание постера...",
	[Key.copied]: "Скопировано",
	[Key.copyLink]: "Копировать ссылку",
	[Key.savePoster]: "Сохранить постер",
	[Key.scanToRead]: "Сканируйте, чтобы прочитать",

	// Конфигурация блоков коллапсируемого кода
	[Key.codeCollapsibleShowMore]: "Развернуть",
	[Key.codeCollapsibleShowLess]: "Свернуть",
	[Key.codeCollapsibleExpanded]: "Блок кода развернут",
	[Key.codeCollapsibleCollapsed]: "Блок кода свернут",

	// Страница галереи
	[Key.gallery]: "Галерея",
	[Key.galleryDescription]: "Запечатлеть прекрасные моменты жизни",
	[Key.galleryPhotos]: "фото",
	[Key.galleryAlbums]: "альбомов",
	[Key.galleryNoAlbums]: "Пока нет альбомов",
	[Key.galleryBackToAlbums]: "Вернуться к альбомам",
	[Key.searchAlbums]: "Поиск альбомов...",

	// Защита паролем
	[Key.passwordProtected]: "Защищено паролем",
	[Key.passwordProtectedDesc]:
		"Этот контент защищён паролем. Пожалуйста, введите пароль для просмотра.",
	[Key.passwordHint]: "Подсказка",
	[Key.passwordPlaceholder]: "Введите пароль",
	[Key.passwordSubmit]: "Разблокировать",
	[Key.passwordError]: "Неверный пароль, попробуйте снова.",
	[Key.passwordProtectedRss]:
		"Эта статья зашифрована. Пожалуйста, посетите сайт для просмотра.",

	// Фоновый видеоплеер
	[Key.videoPlay]: "Воспроизвести фоновое видео",
	[Key.videoPause]: "Пауза фонового видео",
	[Key.videoPrev]: "Предыдущее видео",
	[Key.videoNext]: "Следующее видео",
	[Key.videoLoadError]: "Не удалось загрузить видео",
};
