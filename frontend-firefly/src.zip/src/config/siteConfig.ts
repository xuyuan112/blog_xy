import type { SiteConfig } from "@/types/siteConfig";
import { resolvePageToggles } from "../utils/page-toggle-utils";
import { resolveSiteLang } from "../utils/site-config-utils";

// 定义站点语言
// 语言代码，例如：'zh_CN', 'zh_TW', 'en', 'ja', 'ru', 'ko'。
const SITE_LANG = resolveSiteLang("zh_CN");

// 页面开关配置 - 控制特定页面的访问权限，设为false会返回404并自动隐藏对应的导航栏菜单项
const pages = resolvePageToggles({
	// ── 社交 (Social) ──────────────────────────────────

	// 友链页面开关
	friends: true,
	// 留言板页面开关，需要配置评论系统
	guestbook: true,

	// ── 我的 (My) ──────────────────────────────────

	// 动态页面开关
	dynamic: true,
	// 相册页面开关
	gallery: true,
	// 书签导航页面开关
	booknav: true,
	// 哔哩哔哩追番页面开关
	bilibili: false,
	// 番组计划页面开关
	bangumi: false,
	// VNDB页面开关
	vndb: false,
	// MyAnimeList页面开关
	mal: false,

	// ── 关于 (About) ──────────────────────────────────

	// 打赏页面开关
	sponsor: true,
});

export const siteConfig: SiteConfig = {
	// 站点标题
	title: "Firefly",

	// 站点副标题
	subtitle: "Demo site",

	// 站点 URL
	site_url: "https://firefly.cuteleaf.cn",

	// 站点描述
	description:
		"Firefly 是一款基于 Astro 框架和 Fuwari 模板开发的清新美观且现代化个人博客主题模板，专为技术爱好者和内容创作者设计。该主题融合了现代 Web 技术栈，提供了丰富的功能模块和高度可定制的界面，让您能够轻松打造出专业且美观的个人博客网站。",

	// 站点关键词
	keywords: [
		"Firefly",
		"Fuwari",
		"Astro",
		"ACGN",
		"博客",
		"技术博客",
		"静态博客",
	],

	// 主题色
	themeColor: {
		// 主题色的默认色相，范围从 0 到 360。例如：红色：0，青色：200，蓝绿色：250，粉色：345
		hue: 165,
		// 默认模式："light" 亮色，"dark" 暗色，"system" 跟随系统
		defaultMode: "system",
	},

	// 页面整体宽度（单位：rem）
	// 数值越大可以让页面内容区域更宽
	// 在使用单侧栏边栏时，建议调低一些宽度以获得更好的视觉效果。
	pageWidth: 100,

	// 网站Card样式配置
	card: {
		// 是否开启卡片边框和阴影，开启后让网站更有立体感
		border: false,
		// 是否让卡片风格跟随主题色相
		followTheme: false,
	},

	// Favicon 配置
	// 如果启用了OpenGraph图片功能，数组中需要包含png格式的favicon图标
	favicon: [
		{
			// 图标文件路径
			src: "/favicon/my-icon.png",
			// 可选，指定主题 'light' | 'dark'
			// theme: "light",
			// 可选，图标大小
			// sizes: "32x32",
		},
	],

	// 导航栏配置
	navbar: {
		// 导航栏Logo
		// 支持三种类型：
		// 1. Astro图标库: { type: "icon", value: "material-symbols:home-pin-outline" }
		// 2. 本地图片（public目录，不优化）: { type: "image", value: "/assets/images/logo.webp", alt: "Logo" }
		// 3. 本地图片（src目录，自动优化但会增加构建时间）: { type: "image", value: "assets/images/logo.webp", alt: "Logo" }
		// 4. 网络图片: { type: "url", value: "https://example.com/logo.png", alt: "Logo" }
		// image 和 url 类型可额外设置 valueDark，用于暗色模式下显示另一张图片，不设置则亮暗色共用 value
		// 例如: { type: "image", value: "assets/images/logo.png", valueDark: "assets/images/logo-dark.png", alt: "Logo" }
		// 使用 Astro 图标库时不需要设置 valueDark，图标会自动跟随主题亮暗色切换
		logo: {
			type: "image",
			value: "assets/images/logo/利姆露logo.png",
			alt: "logo",
		},
		// 导航栏标题
		title: "xuyuan",
		// 全宽导航栏，导航栏是否占满屏幕宽度
		widthFull: false,
		// 导航菜单对齐方式，left：左对齐，center：居中
		menuAlign: "center",
		// 导航栏图标和标题是否跟随主题色
		followTheme: false,
		// 导航栏是否固定在顶部并始终可见
		stickyNavbar: true,
	},

	// 站点开始日期，用于统计运行天数
	siteStartDate: "2025-01-01",

	// 站点时区（IANA 时区字符串），用于格式化bangumi、rss里的构建日期时间等等..
	// 示例："Asia/Shanghai", "UTC", 如果为空，则按照构建服务器的时区进行时区转换
	timezone: "Asia/Shanghai",

	// 页面开关配置 - 控制特定页面的访问权限，设为false会返回404并自动隐藏对应的导航栏菜单项

	// 分类导航栏开关，在首页和归档页顶部显示分类快捷导航
	categoryBar: true,

	// 分类导航栏按钮样式
	// "pill"：胶囊，主题色浅底圆角
	// "rectangle"：矩形，配色同胶囊，仅圆角更小
	categoryStyle: "rectangle",

	// 标签样式，作用于文章列表底部标签、标签页和侧边栏标签
	// "pill"：胶囊，主题色底圆角
	// "pill-gray"：胶囊，中性灰底圆角
	// "rectangle"：矩形，主题色底小圆角
	tagStyle: "pill",

	// 归档页是否折叠非最新年份文章，禁用后默认展开全部年份
	foldArticle: true,

	// ── 文章列表布局配置 ──────────────────────────────────
	postListLayout: {
		// 默认布局模式："list" 列表模式（单列布局），"grid" 网格模式（多列布局）
		defaultMode: "list",
		// 移动端默认布局模式，不设置则跟随 defaultMode
		mobileDefaultMode: "grid",
		// 列表模式下封面图显示在哪一侧："right" 右侧，"left" 左侧
		// 网格模式的封面固定在卡片顶部，不受此项影响
		coverPosition: "right",
		// 文章简介显示行数，设为 0 则不截断
		descriptionLines: 2,
		// 文章卡片底部统计和发布日期是否显示图标
		showStatsIcons: true,
		// 标签显示位置
		// 设置为"meta"：显示在文章标题下的元数据
		// 设置为"bottom"：顶替stats在底部显示
		tagsPosition: "bottom",
		// 底部标签样式，仅在 tagsPosition 为 "bottom" 时生效
		// "chip"：按钮样式，形状跟随上方的 tagStyle 配置
		// "text"：无底色，只有文字
		tagsBottomStyle: "chip",
		// PostMeta 元数据显示控制
		meta: {
			// 是否显示发布日期
			showPublished: true,
			// 是否显示分类
			showCategory: true,
			// 是否显示标签
			showTags: true,
			// 标签数量，设为 0 则不限制
			tagCount: 3,
			// 是否显示字数
			showWords: false,
			// 是否显示阅读时间
			showReadingTime: false,
		},
		// 底部 PostStats 统计信息显示控制
		// 如果tagsPosition设置为"bottom"，则stats将不显示
		stats: {
			// 是否显示发布日期
			showPublished: true,
			// 是否显示字数
			showWords: true,
			// 是否显示阅读时间
			showReadingTime: true,
		},
		// 网格布局配置，仅在 defaultMode 为 "grid" 或允许切换布局时生效
		grid: {
			// 是否开启瀑布流布局，同时有封面图和无封面图的混合文章推荐开启
			masonry: false,
			// 网格模式卡片最小宽度(px)，浏览器根据容器宽度自动计算列数
			columnWidth: 320,
			// 网格模式封面是否撑满卡片贴边
			// true：封面顶到卡片左右和上边缘，只有上面两角是圆角
			// false：封面按卡片内边距内缩，上、左、右留出间距，四角都是圆角
			coverFullWidth: false,
		},
	},

	// 分页配置
	pagination: {
		// 每页显示的文章数量
		postsPerPage: 10,
	},

	// ── 文章内容页配置 ──────────────────────────────────
	post: {
		// 提醒框（Admonitions）配置，修改后需要重启开发服务器才能生效
		// 主题：'github' | 'obsidian' | 'vitepress' | 'docusaurus'，每个主题风格和语法不同，可根据喜好选择
		rehypeCallouts: {
			theme: "github",
			// 是否启用兼容 Python-Markdown 风格的 admonition 语法（!!!和???语法）
			// 注意：只有 theme 配置成 obsidian 主题才能基本支持这些语法，其他主题会有样式问题或不兼容的情况
			enablePythonMarkdownAdmonitions: false,
		},
		// 文章页底部的"上次编辑时间"卡片开关
		showLastModified: true,
		// 文章过期阈值（天数），超过此天数才显示"上次编辑"卡片
		outdatedThreshold: 30,
		// 是否开启分享海报生成功能
		sharePoster: true,
		// OpenGraph图片功能，注意开启后要渲染很长时间，不建议本地调试的时候开启
		generateOgImages: true,
	},

	// ── Bilibili配置 ──────────────────────────────────
	bilibili: {
		// 你的 Bilibili 用户 UID
		uid: "38932988",
	},

	// ── 番组计划bangumi配置 ──────────────────────────────────
	bangumi: {
		// Bangumi用户ID
		userId: "1143164",
		// 数据模式：static=构建时获取，dynamic=客户端实时获取
		// static 模式在构建时获取数据并静态渲染，部署后数据不更新
		// dynamic 模式在浏览器中实时请求 API，始终显示最新数据
		mode: "dynamic",
		// Bangumi API 地址
		apiUrl: "https://api.bangumi.pro",
		// 详情页地址
		subjectBaseUrl: "https://api.bangumi.pro/subject/",
		// 条目类型排序，数组中的类型将按顺序优先展示
		// 可选值: "anime" | "book" | "music" | "game" | "real" (暂不支持"real"类型)
		// 未列出的类型将按默认顺序排在后面
		categoryOrder: ["anime", "book", "music", "game"],
		// 控制各分类的启用状态（true/false），未指定的分类默认启用
		// categories: {
		// 	game: false, // 禁用游戏分类显示
		// },
		// NSFW 处理："off" 不过滤 | "blur" 仅模糊封面 | "hide" 隐藏条目
		nsfw: "hide",
	},

	// ── VNDB配置 ──────────────────────────────────
	vndb: {
		// VNDB 用户 ID
		userId: "u358128",
		// 数据模式：static=构建时获取，dynamic=客户端实时获取
		// static 模式在构建时获取数据并静态渲染，部署后数据不更新
		// dynamic 模式在浏览器中实时请求 API，始终显示最新数据
		mode: "static",
		// 构建时下载并压缩封面到 public/vndb-covers，图片由本站服务器提供
		downloadCovers: false,
		// VNDB API 地址
		apiUrl: "https://api.vndb.org/kana",
		// 条目详情页地址，末尾需要带 /
		vnBaseUrl: "https://vndb.org/",
		// 私密列表访问令牌，仅 static 模式下使用；不要把真实令牌提交到公开仓库！
		apiToken: "",
		// NSFW 处理："off" 不过滤 | "blur" 仅模糊封面 | "hide" 隐藏条目
		nsfw: "hide",
	},

	// ── MyAnimeList配置 ──────────────────────────────────
	mal: {
		// MyAnimeList 用户名（列表需为公开状态，私密列表无法读取）
		username: "cuteleaf",
		// MyAnimeList Client ID，在 https://myanimelist.net/apiconfig 注册免费应用后获取
		clientId: "	0ef34371450f9c6c809deaadec6aa8f3",
		// MAL API 地址
		apiUrl: "https://api.myanimelist.net/v2",
		// 动画条目详情页地址，末尾需要带 /
		animeBaseUrl: "https://myanimelist.net/anime/",
		// 漫画条目详情页地址，末尾需要带 /
		mangaBaseUrl: "https://myanimelist.net/manga/",
		// NSFW 处理："off" 不过滤 | "blur" 仅模糊封面 | "hide" 隐藏条目
		nsfw: "hide",
	},

	// ── 图像优化配置 ──────────────────────────────────
	// 图像优化压缩只保留avif或webp
	// 响应式图像是为在不同设备上提高性能而调整的图像。这些图像可以调整大小以适应其容器，并且可以根据访问者的屏幕尺寸和分辨率以不同的大小提供。
	// Astro 仅能对 src 目录下的图像进行优化，src 目录下的图像越多，构建时间会越长
	// Astro 图像文档 https://docs.astro.build/zh-cn/guides/images/
	imageOptimization: {
		// 输出图片格式
		// - "avif": 仅输出 AVIF 格式（最新技术，最小体积，目前兼容性较低，构建时间较长）
		// - "webp": 仅输出 WebP 格式（体积适中，兼容性好，构建时间短）
		// - "both": 同时输出 AVIF 和 WebP（浏览器自动选择最佳格式）
		formats: "webp",
		// 图片压缩质量 (1-100)，值越低体积越小但质量越差，推荐 70-85
		quality: 85,
		// 为特定域名的图片添加 referrerpolicy="no-referrer" 属性
		// 支持通配符 *，例如：["i0.hdslb.com", "*.bilibili.com"]
		// 可解决指定域名图片加载时的 403 问题（如防盗链图片）
		noReferrerDomains: [
			"*.hdslb.com",
			"*.bilibili.com",
			"*.myanimelist.net",
			"*.vndb.org",
		],
	},

	// 站点语言，在本配置文件顶部SITE_LANG定义
	lang: SITE_LANG,

	// 页面开关配置，在本配置文件顶部pages定义
	pages,
};
