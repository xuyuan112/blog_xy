import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from 'axios'
import { ElMessage } from 'element-plus'
import type { ApiResult } from '@/types/api'
import { useUserStore } from '@/stores/user'

type ClientType = 'web' | 'admin'
type RetryConfig = AxiosRequestConfig & { _tokenRetried?: boolean }

const baseURL = import.meta.env.VITE_API_BASE_URL || '/xuyuan'
let refreshPromise: Promise<string> | null = null

function redirectToLogin() {
  const redirect = `${window.location.pathname}${window.location.search}${window.location.hash}`
  window.location.hash = `#/login?redirect=${encodeURIComponent(redirect)}`
}

function refreshAccessToken(): Promise<string> {
  const userStore = useUserStore()
  if (!userStore.refreshToken) {
    return Promise.reject(new Error('refreshToken 不存在'))
  }
  if (!refreshPromise) {
    refreshPromise = axios
      .post<ApiResult<{ accessToken: string; refreshToken: string }>>(
        `${baseURL}/app/auth/refresh`,
        { refreshToken: userStore.refreshToken },
        { headers: { 'X-Client-Type': 'web' }, timeout: 15000 }
      )
      .then((response) => {
        if (response.data.code !== 200 || !response.data.data?.accessToken) {
          throw new Error(response.data.message || 'Token 刷新失败')
        }
        const result = response.data.data
        userStore.setTokens(result.accessToken, result.refreshToken || userStore.refreshToken)
        return result.accessToken
      })
      .finally(() => {
        refreshPromise = null
      })
  }
  return refreshPromise
}

function createService(serviceBaseURL: string, clientType: ClientType): AxiosInstance {
  const service = axios.create({ baseURL: serviceBaseURL, timeout: 15000 })

  service.interceptors.request.use((config) => {
    const token = useUserStore().accessToken
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    config.headers['X-Client-Type'] = clientType
    return config
  })

  service.interceptors.response.use(
    (response: AxiosResponse<ApiResult>) => {
      const { code, message, data } = response.data
      if (code === 200) {
        return data as never
      }

      const originalConfig = response.config as RetryConfig
      if (
        code === 601 &&
        !originalConfig._tokenRetried &&
        !originalConfig.url?.includes('/app/auth/refresh')
      ) {
        originalConfig._tokenRetried = true
        return refreshAccessToken()
          .then((token) => {
            originalConfig.headers = originalConfig.headers || {}
            originalConfig.headers.Authorization = `Bearer ${token}`
            return service.request(originalConfig)
          })
          .catch((error) => {
            useUserStore().logout()
            ElMessage.error('登录状态已失效，请重新登录')
            redirectToLogin()
            return Promise.reject(error)
          })
      }

      if ([401, 602, 603].includes(code)) {
        useUserStore().logout()
        ElMessage.error(message || '登录状态已失效，请重新登录')
        if (
          code !== 603 ||
          originalConfig.url?.includes('/comments') ||
          originalConfig.url?.includes('/likes')
        ) {
          redirectToLogin()
        }
      } else {
        ElMessage.error(message || '请求失败')
      }
      return Promise.reject(new Error(message || `业务错误 ${code}`))
    },
    (error) => {
      ElMessage.error(error.response?.status === 429 ? '操作过于频繁，请稍后再试' : '网络请求失败')
      return Promise.reject(error)
    }
  )

  return service
}

export const webService = createService(baseURL, 'web')
export const authService = webService

export function request<T = unknown>(
  service: AxiosInstance,
  config: AxiosRequestConfig
): Promise<T> {
  return service.request(config) as Promise<T>
}

export const get = <T = unknown>(url: string, params?: object) =>
  request<T>(webService, { method: 'get', url, params })

export const post = <T = unknown>(url: string, data?: object) =>
  request<T>(webService, { method: 'post', url, data })

export const put = <T = unknown>(url: string, data?: object) =>
  request<T>(webService, { method: 'put', url, data })

export const del = <T = unknown>(url: string, params?: object) =>
  request<T>(webService, { method: 'delete', url, params })

export default webService
