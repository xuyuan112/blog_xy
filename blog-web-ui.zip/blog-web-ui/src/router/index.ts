import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    component: () => import('@/layouts/DefaultLayout.vue'),
    children: [
      {
        path: '',
        name: 'Home',
        component: () => import('@/views/home/HomeView.vue'),
        meta: { title: '首页' }
      },
      { path: 'home', redirect: '/' },
      {
        path: 'moments',
        name: 'Moments',
        component: () => import('@/views/moment/MomentView.vue'),
        meta: { title: '说说' }
      },
      {
        path: 'moments/:id',
        name: 'MomentDetail',
        component: () => import('@/views/moment/MomentView.vue'),
        meta: { title: '说说详情' }
      },
      {
        path: 'galleries',
        name: 'Galleries',
        component: () => import('@/views/gallery/GalleryView.vue'),
        meta: { title: '照片墙' }
      },
      {
        path: 'galleries/:id',
        name: 'GalleryDetail',
        component: () => import('@/views/gallery/GalleryView.vue'),
        meta: { title: '相册详情' }
      },
      { path: 'gallery', redirect: '/galleries' },
      {
        path: 'archives',
        name: 'Archives',
        component: () => import('@/views/archive/ArchiveView.vue'),
        meta: { title: '归档' }
      },
      {
        path: 'thoughts',
        name: 'Thoughts',
        component: () => import('@/views/thought/ThoughtView.vue'),
        meta: { title: '杂谈' }
      },
      {
        path: 'friends',
        name: 'Friends',
        component: () => import('@/views/friend/FriendView.vue'),
        meta: { title: '友情链接' }
      },
      {
        path: 'about',
        name: 'About',
        component: () => import('@/views/about/AboutView.vue'),
        meta: { title: '关于我' }
      },
      {
        path: 'articles',
        name: 'Articles',
        component: () => import('@/views/home/HomeView.vue'),
        meta: { title: '文章' }
      },
      {
        path: 'articles/:id',
        name: 'ArticleDetail',
        component: () => import('@/views/article/ArticleDetailView.vue'),
        meta: { title: '文章详情' }
      },
      {
        path: 'search',
        name: 'Search',
        component: () => import('@/views/search/SearchView.vue'),
        meta: { title: '搜索' }
      },
      {
        path: 'login',
        name: 'Login',
        component: () => import('@/views/auth/LoginView.vue'),
        meta: { title: '登录' }
      },
      {
        path: 'register',
        name: 'Register',
        component: () => import('@/views/auth/RegisterView.vue'),
        meta: { title: '注册' }
      },
      {
        path: 'settings/password',
        name: 'PasswordSettings',
        component: () => import('@/views/auth/PasswordView.vue'),
        meta: { title: '修改密码', requiresAuth: true }
      },
      { path: ':pathMatch(.*)*', name: 'NotFound', component: () => import('@/views/NotFoundView.vue'), meta: { title: '页面不存在' } }
    ]
  }
]
const router = createRouter({
  history: createWebHashHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})
router.beforeEach((to) => {
  if (to.meta.requiresAuth) {
    const raw = localStorage.getItem('blog-user')
    const hasToken = raw ? Boolean(JSON.parse(raw).accessToken) : false
    if (!hasToken) {
      return { path: '/login', query: { redirect: to.fullPath } }
    }
  }
})
router.afterEach((to) => {
  document.title = `${String(to.meta.title || '首页')} - Xuyuan Blog`
})
export default router
