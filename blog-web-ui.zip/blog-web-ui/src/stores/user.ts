import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
export interface UserInfo { userId: number; username: string; nickname: string; avatar: string | null; email?: string | null }
export const useUserStore = defineStore('user', () => {
  const accessToken = ref(''); const refreshToken = ref(''); const userInfo = ref<UserInfo | null>(null)
  const isLogin = computed(() => Boolean(accessToken.value))
  const setTokens = (access: string, refresh: string) => { accessToken.value = access; refreshToken.value = refresh }
  const setUserInfo = (info: UserInfo) => { userInfo.value = info }
  const logout = () => { accessToken.value = ''; refreshToken.value = ''; userInfo.value = null }
  return { accessToken, refreshToken, userInfo, isLogin, setTokens, setUserInfo, logout }
}, { persist: { key: 'blog-user', storage: localStorage } })
