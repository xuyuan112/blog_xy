<script setup lang="ts">
defineProps<{ as?: string }>()
</script>
<template><component :is="as || 'section'" class="base-card"><slot /></component></template>
<style scoped>.base-card{background:var(--blog-card-bg);border:1px solid var(--blog-border);border-radius:8px;padding:20px}</style>
