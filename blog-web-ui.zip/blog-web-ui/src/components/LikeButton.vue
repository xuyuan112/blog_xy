<script setup lang="ts">
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { toggleLike } from '@/api/like'

const props = defineProps<{ targetType: number; targetId: number; initialCount?: number }>()
const liked = ref(false)
const likeCount = ref(props.initialCount || 0)
const loading = ref(false)

async function toggle() {
  if (loading.value) return
  loading.value = true
  const previous = { liked: liked.value, count: likeCount.value }
  liked.value = !liked.value
  likeCount.value += liked.value ? 1 : -1
  try {
    const result = await toggleLike(props.targetType, props.targetId)
    liked.value = result.liked
    likeCount.value = result.likeCount
  } catch {
    liked.value = previous.liked
    likeCount.value = previous.count
    ElMessage.error('点赞操作失败，请稍后重试')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <button
    type="button"
    class="like-button"
    :class="{ liked }"
    :disabled="loading"
    :aria-pressed="liked"
    @click="toggle"
  >
    <span aria-hidden="true">{{ liked ? '♥' : '♡' }}</span>
    <span>{{ likeCount }}</span>
  </button>
</template>

<style scoped>
.like-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: 1px solid var(--blog-border);
  border-radius: 6px;
  padding: 6px 11px;
  background: var(--blog-card-bg);
  color: var(--blog-muted);
  cursor: pointer;
  transition: 0.2s;
}
.like-button:hover,
.like-button.liked {
  border-color: #e25555;
  color: #e25555;
  background: #fff5f5;
}
.like-button:disabled {
  opacity: 0.6;
  cursor: wait;
}
</style>
