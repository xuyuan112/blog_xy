<script setup lang="ts">
function backTop() { window.scrollTo({ top: 0, behavior: "smooth" }) }
</script>
<template><button class="back-top" aria-label="返回顶部" title="返回顶部" @click="backTop">↑</button></template>
