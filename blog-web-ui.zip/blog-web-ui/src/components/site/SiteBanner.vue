<script setup lang="ts">
defineProps<{ title?: string; subtitle?: string }>()
</script>
<template>
  <section class="site-banner" aria-label="站点横幅">
    <div class="banner-overlay">
      <p class="banner-kicker">XUYUAN BLOG</p>
      <h1>{{ title || "记录技术，也记录生活" }}</h1>
      <p>{{ subtitle || "在实践中学习，在分享中成长" }}</p>
    </div>
  </section>
</template>
