<template><footer class="site-footer">© {{ new Date().getFullYear() }} Yujing Blog</footer></template>
