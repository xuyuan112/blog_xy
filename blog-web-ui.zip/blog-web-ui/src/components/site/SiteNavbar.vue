<script setup lang="ts">
import { computed, ref } from "vue"
import { RouterLink, useRoute, useRouter } from "vue-router"
import { useUserStore } from "@/stores/user"

const route = useRoute()
const router = useRouter()
const user = useUserStore()
const drawerOpen = ref(false)
const darkMode = ref(document.documentElement.dataset.theme === "dark")
const navs = [
  { path: "/", label: "首页", icon: "⌂" }, { path: "/archives", label: "归档", icon: "▤" },
  { path: "/galleries", label: "相册", icon: "▧" }, { path: "/moments", label: "动态", icon: "✦" },
  { path: "/friends", label: "友链", icon: "↗" }, { path: "/about", label: "关于", icon: "ⓘ" }
]
const activePath = computed(() => route.path === "/" ? "/" : `/${route.path.split("/")[1]}`)
function openSearch() { router.push("/search") }
function toggleTheme() {
  darkMode.value = !darkMode.value
  document.documentElement.dataset.theme = darkMode.value ? "dark" : "light"
  localStorage.setItem("blog-theme", darkMode.value ? "dark" : "light")
}
</script>
<template>
  <header class="site-header">
    <div class="header-inner">
      <button class="icon-button mobile-menu" aria-label="打开导航" @click="drawerOpen = !drawerOpen">☰</button>
      <RouterLink to="/" class="brand" aria-label="返回首页"><span class="brand-mark">Y</span><span>Yujing</span></RouterLink>
      <nav class="desktop-nav" aria-label="主导航"><RouterLink v-for="item in navs" :key="item.path" :to="item.path" :class="{ active: activePath === item.path }"><span aria-hidden="true">{{ item.icon }}</span>{{ item.label }}</RouterLink></nav>
      <div class="header-actions"><button class="icon-button" aria-label="搜索" title="搜索" @click="openSearch">⌕</button><button class="icon-button" :aria-label="darkMode ? '切换亮色主题' : '切换暗色主题'" title="切换主题" @click="toggleTheme">{{ darkMode ? "☼" : "☾" }}</button><RouterLink class="icon-button" :to="user.isLogin ? '/settings/password' : '/login'" :aria-label="user.isLogin ? '账户设置' : '登录'" title="账户">●</RouterLink></div>
    </div>
    <nav v-if="drawerOpen" class="mobile-nav" aria-label="移动端导航"><RouterLink v-for="item in navs" :key="item.path" :to="item.path" :class="{ active: activePath === item.path }" @click="drawerOpen = false"><span aria-hidden="true">{{ item.icon }}</span>{{ item.label }}</RouterLink></nav>
  </header>
</template>
