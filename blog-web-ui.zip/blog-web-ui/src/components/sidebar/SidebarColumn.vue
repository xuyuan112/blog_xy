<script setup lang="ts">
import { RouterLink, useRoute } from "vue-router"
import { computed } from "vue"
const route = useRoute()
const navs = [
  { path: "/", label: "首页", icon: "⌂" }, { path: "/archives", label: "归档", icon: "▤" },
  { path: "/galleries", label: "相册", icon: "▧" }, { path: "/moments", label: "动态", icon: "✦" },
  { path: "/friends", label: "友链", icon: "↗" }, { path: "/about", label: "关于", icon: "ⓘ" }
]
const activePath = computed(() => route.path === "/" ? "/" : `/${route.path.split("/")[1]}`)
</script>
<template>
  <aside class="left-rail"><section class="profile-panel glass-card"><img class="profile-avatar" src="/placeholder.svg" alt="站点头像占位图" /><strong>Yujing</strong><span>记录技术，也记录生活</span><div class="profile-stats"><span><b>--</b>文章</span><span><b>--</b>分类</span><span><b>--</b>标签</span></div></section><section class="rail-section glass-card"><h2>探索</h2><nav><RouterLink v-for="item in navs" :key="item.path" :to="item.path" :class="{ active: activePath === item.path }"><span aria-hidden="true">{{ item.icon }}</span>{{ item.label }}</RouterLink></nav></section></aside>
</template>
