<script setup lang="ts">
import { computed } from "vue"
const props = defineProps<{ content?: string }>()
const escapeHtml = (value: string) => value.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] || c)
const html = computed(() => {
  const lines = (props.content || "").replace(/\r\n?/g, "\n").split("\n")
  let result = ""
  let paragraph: string[] = []
  const flush = () => { if (paragraph.length) { result += "<p>" + paragraph.map((line) => escapeHtml(line)).join("<br>") + "</p>"; paragraph = [] } }
  for (const line of lines) {
    const heading = line.match(/^(#{1,6})\s+(.+?)\s*#*$/)
    if (heading) { flush(); const level = heading[1].length; const text = heading[2].trim(); result += "<h" + level + " id=\"" + text.replace(/\s+/g, "-") + "\">" + escapeHtml(text) + "</h" + level + ">"; continue }
    if (!line.trim()) { flush(); continue }
    paragraph.push(line)
  }
  flush()
  return result
})
</script>
<template><div class="markdown-body" v-html="html" /></template>
