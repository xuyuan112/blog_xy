<script setup lang="ts">
import type { ArticleListItem } from "@/api/article"
defineProps<{ article: ArticleListItem }>()
</script>
<template>
  <article class="article-card blog-card">
    <div v-if="article.cover" class="cover-wrap"><img :src="article.cover" :alt="article.title" loading="lazy" /></div>
    <div class="article-body"><div class="article-top"><span class="category">{{ article.categoryName || "未分类" }}</span><span v-if="article.isTop" class="top-badge">置顶</span></div><h2>{{ article.title }}</h2><p class="summary">{{ article.summary || "暂无摘要" }}</p><div class="meta"><span>阅读 {{ article.viewCount }}</span><span>评论 {{ article.commentCount }}</span><time>{{ article.publishedAt }}</time></div></div>
  </article>
</template>
