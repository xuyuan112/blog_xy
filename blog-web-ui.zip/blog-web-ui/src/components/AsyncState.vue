<script setup lang="ts">
defineProps<{ loading?: boolean; error?: string; empty?: boolean; emptyText?: string }>()
defineEmits<{ retry: [] }>()
</script>
<template>
  <div v-if="loading" class="state"><span class="spinner" />正在加载</div>
  <div v-else-if="error" class="state error"><p>{{ error }}</p><button type="button" @click="$emit('retry')">重试</button></div>
  <div v-else-if="empty" class="state">{{ emptyText || '暂无内容' }}</div>
  <slot v-else />
</template>
<style scoped>.state{padding:48px 20px;text-align:center;color:var(--blog-muted);font-size:14px}.error button{border:1px solid var(--blog-border);background:#fff;border-radius:5px;padding:5px 12px;color:var(--blog-primary);cursor:pointer}.spinner{display:inline-block;width:16px;height:16px;margin-right:8px;border:2px solid #d8e4f5;border-top-color:var(--blog-primary);border-radius:50%;vertical-align:-3px;animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}</style>
