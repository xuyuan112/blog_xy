<script setup lang="ts">
withDefaults(defineProps<{ src?: string; alt?: string; lazy?: boolean }>(), { alt: '', lazy: true })
</script>
<template><img class="responsive-image" :src="src || '/placeholder.svg'" :alt="alt" :loading="lazy ? 'lazy' : 'eager'" @error="($event.target as HTMLImageElement).src = '/placeholder.svg'" /></template>
<style scoped>.responsive-image{display:block;width:100%;height:100%;object-fit:cover;background:#eef2f6}</style>
