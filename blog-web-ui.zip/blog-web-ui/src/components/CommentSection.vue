<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { createComment, getCommentPage, type Comment } from '@/api/comment'
import { useUserStore } from '@/stores/user'
import { useRouter } from 'vue-router'

const props = defineProps<{ targetType: number; targetId: number }>()
const userStore = useUserStore()
const router = useRouter()
const comments = ref<Comment[]>([])
const loading = ref(false)
const submitting = ref(false)
const form = ref({ nickname: '', email: '', website: '', content: '' })

async function load() {
  loading.value = true
  try {
    const result = await getCommentPage({
      targetType: props.targetType,
      targetId: props.targetId,
      page: 1,
      pageSize: 20
    })
    comments.value = result.records
  } catch {
    ElMessage.error('评论加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

async function submit() {
  if (!form.value.nickname.trim() || !form.value.content.trim()) {
    ElMessage.warning('请填写昵称和评论内容')
    return
  }
  submitting.value = true
  try {
    await createComment({
      targetType: props.targetType,
      targetId: props.targetId,
      ...form.value,
      nickname: form.value.nickname.trim(),
      content: form.value.content.trim()
    })
    ElMessage.success('评论已提交，审核通过后显示')
    form.value = { nickname: '', email: '', website: '', content: '' }
  } finally {
    submitting.value = false
  }
}

onMounted(load)
</script>

<template>
  <section class="comment-section" aria-labelledby="comment-title">
    <div class="section-heading">
      <h2 id="comment-title">评论</h2>
      <span>{{ comments.length }} 条</span>
    </div>
    <div v-loading="loading" class="comment-list">
      <article v-for="comment in comments" :key="comment.id" class="comment-item">
        <el-avatar :src="comment.avatar" :size="34">{{ comment.nickname.slice(0, 1) }}</el-avatar>
        <div class="comment-body">
          <div class="comment-meta">
            <strong>{{ comment.nickname }}</strong
            ><time>{{ comment.createdAt }}</time>
          </div>
          <p>{{ comment.content }}</p>
        </div>
      </article>
      <el-empty v-if="!loading && !comments.length" description="暂无评论，欢迎留下第一条评论" />
    </div>
    <div v-if="!userStore.isLogin" class="login-hint">
      <span>登录后即可发表评论</span
      ><el-button
        type="primary"
        text
        @click="
          router.push({ path: '/login', query: { redirect: router.currentRoute.value.fullPath } })
        "
        >去登录</el-button
      >
    </div>
    <form v-else class="comment-form" @submit.prevent="submit">
      <div class="form-row">
        <el-input v-model="form.nickname" maxlength="64" placeholder="昵称 *" /><el-input
          v-model="form.email"
          type="email"
          placeholder="邮箱（可选）"
        /><el-input v-model="form.website" placeholder="网站（可选）" />
      </div>
      <el-input
        v-model="form.content"
        type="textarea"
        :rows="4"
        maxlength="1000"
        show-word-limit
        placeholder="写下你的想法 *"
      />
      <div class="form-actions">
        <el-button type="primary" native-type="submit" :loading="submitting">提交评论</el-button>
      </div>
    </form>
  </section>
</template>

<style scoped lang="scss">
.comment-section {
  margin-top: 28px;
  padding-top: 24px;
  border-top: 1px solid var(--blog-border);
}
.section-heading {
  display: flex;
  align-items: baseline;
  gap: 9px;
  margin-bottom: 16px;
}
.section-heading h2 {
  margin: 0;
  font-size: 20px;
}
.section-heading span {
  color: var(--blog-muted);
  font-size: 12px;
}
.comment-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.comment-item {
  display: flex;
  gap: 10px;
}
.comment-body {
  min-width: 0;
  flex: 1;
}
.comment-meta {
  display: flex;
  gap: 10px;
  align-items: baseline;
}
.comment-meta strong {
  font-size: 14px;
}
.comment-meta time {
  color: var(--blog-muted);
  font-size: 11px;
}
.comment-body p {
  margin: 4px 0 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-size: 14px;
  line-height: 1.65;
}
.comment-form {
  margin-top: 22px;
  padding: 16px;
  background: color-mix(in srgb, var(--blog-bg) 70%, white);
  border: 1px solid var(--blog-border);
  border-radius: 6px;
}
.login-hint {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 20px;
  padding: 14px 16px;
  border: 1px solid var(--blog-border);
  border-radius: 6px;
  color: var(--blog-muted);
  font-size: 13px;
}
.form-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
  margin-bottom: 10px;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
}
@media (max-width: 600px) {
  .form-row {
    grid-template-columns: 1fr;
  }
}
</style>
