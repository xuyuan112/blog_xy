<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { changePassword } from '@/api/auth'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const form = ref({ oldPassword: '', newPassword: '', confirmPassword: '' })
const loading = ref(false)

async function submit() {
  if (!form.value.oldPassword || form.value.newPassword.length < 6) {
    ElMessage.warning('请输入原密码和至少 6 位新密码')
    return
  }
  if (form.value.newPassword !== form.value.confirmPassword) {
    ElMessage.warning('两次输入的密码不一致')
    return
  }
  loading.value = true
  try {
    await changePassword({
      oldPassword: form.value.oldPassword,
      newPassword: form.value.newPassword
    })
    userStore.logout()
    ElMessage.success('密码已修改，请重新登录')
    router.replace('/login')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <section class="auth-page">
    <div class="auth-card blog-card">
      <p class="eyebrow">ACCOUNT</p>
      <h1>修改密码</h1>
      <p class="subtitle">修改成功后需要重新登录。</p>
      <el-form label-position="top" @submit.prevent="submit"
        ><el-form-item label="原密码"
          ><el-input
            v-model="form.oldPassword"
            type="password"
            show-password
            autocomplete="current-password" /></el-form-item
        ><el-form-item label="新密码"
          ><el-input
            v-model="form.newPassword"
            type="password"
            show-password
            autocomplete="new-password" /></el-form-item
        ><el-form-item label="确认新密码"
          ><el-input
            v-model="form.confirmPassword"
            type="password"
            show-password
            autocomplete="new-password" /></el-form-item
        ><el-button type="primary" native-type="submit" :loading="loading" class="submit"
          >确认修改</el-button
        ></el-form
      >
    </div>
  </section>
</template>

<style scoped>
.auth-page {
  display: grid;
  place-items: center;
  min-height: 60vh;
}
.auth-card {
  width: min(420px, 100%);
  padding: 30px;
}
.eyebrow {
  margin: 0 0 5px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.7px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: 30px;
}
.subtitle {
  margin: 7px 0 23px;
  color: var(--blog-muted);
}
.submit {
  width: 100%;
  margin-top: 8px;
}
</style>
