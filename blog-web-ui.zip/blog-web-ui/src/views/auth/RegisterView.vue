<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { register } from '@/api/auth'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const form = ref({ username: '', password: '', confirmPassword: '', nickname: '', email: '' })
const loading = ref(false)

async function submit() {
  if (!form.value.username.trim() || !form.value.password || !form.value.nickname.trim()) {
    ElMessage.warning('请填写用户名、密码和昵称')
    return
  }
  if (form.value.password !== form.value.confirmPassword) {
    ElMessage.warning('两次输入的密码不一致')
    return
  }
  loading.value = true
  try {
    const result = await register({
      ...form.value,
      username: form.value.username.trim(),
      nickname: form.value.nickname.trim()
    })
    userStore.setTokens(result.accessToken, result.refreshToken)
    if (result.userInfo) userStore.setUserInfo(result.userInfo)
    ElMessage.success('注册成功')
    router.replace('/')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <section class="auth-page">
    <div class="auth-card blog-card">
      <p class="eyebrow">JOIN THE JOURNEY</p>
      <h1>注册</h1>
      <p class="subtitle">创建账号，加入博客讨论。</p>
      <el-form label-position="top" @submit.prevent="submit"
        ><el-form-item label="用户名"
          ><el-input v-model="form.username" autocomplete="username" maxlength="32" /></el-form-item
        ><el-form-item label="昵称"
          ><el-input v-model="form.nickname" maxlength="64" /></el-form-item
        ><el-form-item label="邮箱（可选）"
          ><el-input v-model="form.email" type="email" autocomplete="email" /></el-form-item
        ><el-form-item label="密码"
          ><el-input
            v-model="form.password"
            type="password"
            autocomplete="new-password"
            show-password /></el-form-item
        ><el-form-item label="确认密码"
          ><el-input
            v-model="form.confirmPassword"
            type="password"
            autocomplete="new-password"
            show-password /></el-form-item
        ><el-button type="primary" native-type="submit" :loading="loading" class="submit"
          >注册</el-button
        ></el-form
      >
      <p class="switch">已有账号？<RouterLink to="/login">返回登录</RouterLink></p>
    </div>
  </section>
</template>

<style scoped>
.auth-page {
  display: grid;
  place-items: center;
  min-height: 60vh;
}
.auth-card {
  width: min(420px, 100%);
  padding: 30px;
}
.eyebrow {
  margin: 0 0 5px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.7px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: 30px;
}
.subtitle {
  margin: 7px 0 23px;
  color: var(--blog-muted);
}
.submit {
  width: 100%;
  margin-top: 8px;
}
.switch {
  text-align: center;
  color: var(--blog-muted);
  font-size: 13px;
}
.switch a {
  color: var(--blog-primary);
}
</style>
