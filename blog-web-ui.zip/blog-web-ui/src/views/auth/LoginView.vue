<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { login } from '@/api/auth'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const form = ref({ username: '', password: '' })
const loading = ref(false)

async function submit() {
  if (!form.value.username.trim() || !form.value.password) {
    ElMessage.warning('请输入用户名和密码')
    return
  }
  loading.value = true
  try {
    const result = await login({
      username: form.value.username.trim(),
      password: form.value.password
    })
    userStore.setTokens(result.accessToken, result.refreshToken)
    if (result.userInfo) userStore.setUserInfo(result.userInfo)
    ElMessage.success('登录成功')
    router.replace(typeof route.query.redirect === 'string' ? route.query.redirect : '/')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <section class="auth-page">
    <div class="auth-card blog-card">
      <p class="eyebrow">WELCOME BACK</p>
      <h1>登录</h1>
      <p class="subtitle">登录后参与评论和点赞。</p>
      <el-form label-position="top" @submit.prevent="submit"
        ><el-form-item label="用户名"
          ><el-input v-model="form.username" autocomplete="username" maxlength="32" /></el-form-item
        ><el-form-item label="密码"
          ><el-input
            v-model="form.password"
            type="password"
            autocomplete="current-password"
            show-password /></el-form-item
        ><el-button type="primary" native-type="submit" :loading="loading" class="submit"
          >登录</el-button
        ></el-form
      >
      <p class="switch">还没有账号？<RouterLink to="/register">立即注册</RouterLink></p>
    </div>
  </section>
</template>

<style scoped>
.auth-page {
  display: grid;
  place-items: center;
  min-height: 60vh;
}
.auth-card {
  width: min(420px, 100%);
  padding: 30px;
}
.eyebrow {
  margin: 0 0 5px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.7px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: 30px;
}
.subtitle {
  margin: 7px 0 23px;
  color: var(--blog-muted);
}
.submit {
  width: 100%;
  margin-top: 8px;
}
.switch {
  text-align: center;
  color: var(--blog-muted);
  font-size: 13px;
}
.switch a {
  color: var(--blog-primary);
}
</style>
