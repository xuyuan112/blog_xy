<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue"
import { useRoute, useRouter } from "vue-router"
import { getArticlePage, getHotArticles, type ArticleListItem } from "@/api/article"
import ArticleCard from "@/components/article/ArticleCard.vue"

const route = useRoute(); const router = useRouter(); const articles = ref<ArticleListItem[]>([]); const hot = ref<{ id: number; title: string; viewCount: number }[]>([]); const loading = ref(false); const error = ref(false); const page = ref(1); const total = ref(0)
const filters = computed(() => ({ categoryId: route.query.categoryId ? Number(route.query.categoryId) : undefined, tagId: route.query.tagId ? Number(route.query.tagId) : undefined }))
const hasMore = computed(() => articles.value.length < total.value)
async function load(reset = true) { if (reset) page.value = 1; loading.value = true; error.value = false; try { const result = await getArticlePage({ page: page.value, pageSize: 10, ...filters.value }); articles.value = reset ? result.records : [...articles.value, ...result.records]; total.value = result.total } catch { error.value = true } finally { loading.value = false } }
async function loadHot() { try { hot.value = await getHotArticles(5) } catch { hot.value = [] } }
function more() { if (!loading.value && hasMore.value) { page.value += 1; load(false) } }
onMounted(() => { load(); loadHot() }); watch(() => [route.query.categoryId, route.query.tagId], () => load())
</script>
<template>
  <section class="home-page"><header class="hero"><p class="eyebrow">LATEST POSTS</p><h1>最新文章</h1><p>记录实践与思考，持续更新中</p></header>
    <div class="home-grid"><main class="content-column"><div v-if="error" class="state-card blog-card"><p>文章加载失败</p><button type="button" @click="load()">重试</button></div><div v-else class="article-list" :aria-busy="loading"><button v-for="item in articles" :key="item.id" class="article-link" type="button" @click="router.push(`/articles/${item.id}`)"><ArticleCard :article="item" /></button><p v-if="!loading && !articles.length" class="state-card blog-card">暂无文章</p><button v-if="hasMore" class="load-more" type="button" :disabled="loading" @click="more">{{ loading ? "加载中…" : "加载更多" }}</button></div></main>
      <aside class="sidebar-column"><section class="side-card blog-card"><h2>热门文章</h2><button v-for="(item,index) in hot" :key="item.id" class="hot-item" type="button" @click="router.push(`/articles/${item.id}`)"><b>{{ index + 1 }}</b><span>{{ item.title }}</span></button><p v-if="!hot.length" class="muted">热门排行待接入</p></section></aside>
    </div>
  </section>
</template>
<style scoped>
.hero{padding:8px 0 20px}.hero h1{margin:0;font-size:clamp(26px,4vw,38px)}.hero p:last-child{margin:9px 0 0;color:var(--blog-muted)}.home-grid{display:grid;grid-template-columns:minmax(0,1fr) 260px;gap:24px}.article-list{display:flex;flex-direction:column;gap:16px}.article-link{display:block;width:100%;padding:0;border:0;background:none;text-align:left;cursor:pointer}.article-link:hover .article-card{transform:translateY(-2px)}.article-card{transition:transform .2s}.sidebar-column{display:flex;flex-direction:column;gap:14px}.side-card{padding:16px}.side-card h2{margin:0 0 10px;font-size:14px}.hot-item{display:flex;align-items:center;gap:9px;width:100%;padding:7px 0;border:0;border-bottom:1px solid var(--blog-border);background:none;text-align:left;cursor:pointer}.hot-item b{width:20px;color:var(--blog-primary)}.hot-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px}.load-more{align-self:center;padding:8px 16px;border:1px solid var(--blog-border);border-radius:8px;background:var(--blog-card-bg);color:var(--blog-primary);cursor:pointer}.state-card{text-align:center;color:var(--blog-muted)}.state-card button{padding:6px 12px;border:1px solid var(--blog-border);border-radius:6px;background:var(--blog-card-bg);cursor:pointer}@media(max-width:900px){.home-grid{grid-template-columns:1fr}} 
</style>
