<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import {
  applyFriend,
  getFriendList,
  getRandomFriend,
  type Friend,
  type FriendGroup
} from '@/api/site'

const groups = ref<FriendGroup[]>([])
const total = ref(0)
const loading = ref(false)
const activeGroup = ref('全部')
const applyVisible = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref({
  name: '',
  url: '',
  avatar: '',
  description: '',
  email: '',
  group: ''
})

const rules: FormRules = {
  name: [{ required: true, message: '请输入站点名称', trigger: 'blur' }],
  url: [
    { required: true, message: '请输入站点地址', trigger: 'blur' },
    { type: 'url', message: '请输入有效的 URL', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入联系邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入有效的邮箱', trigger: 'blur' }
  ]
}

const groupNames = computed(() => ['全部', ...groups.value.map((group) => group.name)])
const visibleGroups = computed(() => {
  if (activeGroup.value === '全部') return groups.value
  return groups.value.filter((group) => group.name === activeGroup.value)
})

async function load(group?: string) {
  loading.value = true
  try {
    const result = await getFriendList(group)
    groups.value = result.groups
    total.value = result.total
  } catch {
    ElMessage.error('友情链接加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

async function switchGroup(group: string) {
  activeGroup.value = group
  await load(group === '全部' ? undefined : group)
}

async function randomVisit() {
  try {
    const friend = await getRandomFriend()
    if (friend?.url) window.open(friend.url, '_blank', 'noopener,noreferrer')
  } catch {
    ElMessage.error('暂时没有可访问的友情链接')
  }
}

function resetForm() {
  form.value = { name: '', url: '', avatar: '', description: '', email: '', group: '' }
  formRef.value?.clearValidate()
}

async function submitApply() {
  if (!formRef.value) return
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    await applyFriend(form.value)
    ElMessage.success('申请已提交，等待审核')
    applyVisible.value = false
    resetForm()
  } finally {
    submitting.value = false
  }
}

onMounted(() => load())
</script>

<template>
  <section class="friend-page">
    <header class="page-heading">
      <div>
        <p class="eyebrow">FRIENDS</p>
        <h1>友情链接</h1>
        <p class="subtitle">和认真创作的人保持连接。</p>
      </div>
      <div class="actions">
        <el-button @click="randomVisit">随机访问</el-button
        ><el-button type="primary" @click="applyVisible = true">申请友链</el-button>
      </div>
    </header>

    <div class="summary blog-card">
      <strong>{{ total }}</strong
      ><span>个已通过审核的站点</span>
    </div>
    <nav class="group-tabs" aria-label="友情链接分组">
      <button
        v-for="group in groupNames"
        :key="group"
        type="button"
        :class="{ active: activeGroup === group }"
        @click="switchGroup(group)"
      >
        {{ group }}
      </button>
    </nav>

    <div v-loading="loading" class="groups">
      <section v-for="group in visibleGroups" :key="group.name" class="group-section">
        <h2>{{ group.name }}</h2>
        <div class="friend-grid">
          <a
            v-for="friend in group.friends"
            :key="friend.id"
            class="friend-card blog-card"
            :href="friend.url"
            target="_blank"
            rel="noopener noreferrer"
            ><el-avatar :src="friend.avatar" :alt="friend.name" :size="48">{{
              friend.name.slice(0, 1)
            }}</el-avatar>
            <div class="friend-info">
              <h3>{{ friend.name }}</h3>
              <p>{{ friend.description || '暂无站点描述' }}</p>
            </div>
            <span class="external-mark" aria-hidden="true">↗</span></a
          >
        </div>
      </section>
      <el-empty v-if="!loading && !visibleGroups.length" description="暂无友情链接" />
    </div>

    <el-dialog
      v-model="applyVisible"
      title="申请友情链接"
      width="min(520px, calc(100vw - 32px))"
      @closed="resetForm"
      ><el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-position="top"
        @submit.prevent="submitApply"
        ><el-form-item label="站点名称" prop="name"
          ><el-input v-model="form.name" maxlength="80" /></el-form-item
        ><el-form-item label="站点地址" prop="url"
          ><el-input v-model="form.url" placeholder="https://example.com" /></el-form-item
        ><el-form-item label="联系邮箱" prop="email"><el-input v-model="form.email" /></el-form-item
        ><el-form-item label="头像地址"
          ><el-input v-model="form.avatar" placeholder="可选" /></el-form-item
        ><el-form-item label="站点描述"
          ><el-input
            v-model="form.description"
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit /></el-form-item
        ><el-form-item label="分组"
          ><el-input v-model="form.group" placeholder="可选，例如：技术博客"
        /></el-form-item>
        <div class="dialog-actions">
          <el-button @click="applyVisible = false">取消</el-button
          ><el-button type="primary" :loading="submitting" @click="submitApply">提交申请</el-button>
        </div></el-form
      ></el-dialog
    >
  </section>
</template>

<style scoped lang="scss">
.page-heading {
  display: flex;
  justify-content: space-between;
  align-items: end;
  margin-bottom: 24px;
}
.eyebrow {
  margin: 0 0 4px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.8px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: clamp(24px, 4vw, 34px);
}
.subtitle {
  margin: 8px 0 0;
  color: var(--blog-muted);
}
.actions {
  display: flex;
  gap: 8px;
}
.summary {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 16px;
  color: var(--blog-muted);
}
.summary strong {
  font-size: 24px;
  color: var(--blog-text);
}
.group-tabs {
  display: flex;
  gap: 6px;
  overflow: auto;
  margin-bottom: 24px;
  padding-bottom: 2px;
}
.group-tabs button {
  border: 1px solid var(--blog-border);
  background: var(--blog-card-bg);
  color: var(--blog-muted);
  border-radius: 5px;
  padding: 7px 13px;
  cursor: pointer;
  white-space: nowrap;
}
.group-tabs button.active,
.group-tabs button:hover {
  border-color: var(--blog-primary);
  color: var(--blog-primary);
  background: #edf4ff;
}
.groups {
  display: flex;
  flex-direction: column;
  gap: 30px;
}
.group-section h2 {
  margin: 0 0 12px;
  font-size: 18px;
}
.friend-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 14px;
}
.friend-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  transition:
    transform 0.2s,
    box-shadow 0.2s;
}
.friend-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px #17212b14;
}
.friend-info {
  min-width: 0;
  flex: 1;
}
.friend-info h3 {
  margin: 0;
  font-size: 15px;
}
.friend-info p {
  overflow: hidden;
  margin: 3px 0 0;
  color: var(--blog-muted);
  font-size: 13px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.external-mark {
  color: var(--blog-muted);
  font-size: 18px;
}
.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
@media (max-width: 600px) {
  .page-heading {
    display: block;
  }
  .actions {
    margin-top: 16px;
  }
  .actions .el-button {
    flex: 1;
  }
  .friend-grid {
    grid-template-columns: 1fr;
  }
}
</style>
