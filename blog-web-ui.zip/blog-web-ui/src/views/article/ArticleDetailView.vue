<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getArticleDetail, type ArticleDetail } from '@/api/article'
import CommentSection from '@/components/CommentSection.vue'
import LikeButton from '@/components/LikeButton.vue'

const route = useRoute()
const router = useRouter()
const article = ref<ArticleDetail | null>(null)
const loading = ref(false)
const copying = ref(false)
const previewImage = ref('')

const articleId = computed(() => Number(route.params.id) || 0)

function escapeHtml(value: string) {
  return value.replace(
    /[&<>"']/g,
    (char) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] || char
  )
}

function renderInline(value: string) {
  let html = escapeHtml(value)
  html = html.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, '<img src="$2" alt="$1" title="$3" loading="lazy">')
  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>')
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>')
  return html
}

function renderMarkdown(markdown: string) {
  const lines = (markdown || '').replace(/\r\n?/g, '\n').split('\n')
  const output: string[] = []
  let paragraph: string[] = []
  let list: string[] = []
  let ordered = false
  let quote: string[] = []
  let code: string[] = []
  let codeLang = ''
  const flushParagraph = () => { if (paragraph.length) { output.push(`<p>${paragraph.map(renderInline).join('<br>')}</p>`); paragraph = [] } }
  const flushList = () => { if (list.length) { output.push(`<${ordered ? 'ol' : 'ul'}>${list.join('')}</${ordered ? 'ol' : 'ul'}>`); list = [] } }
  const flushQuote = () => { if (quote.length) { output.push(`<blockquote>${quote.map(renderInline).join('<br>')}</blockquote>`); quote = [] } }
  for (const line of lines) {
    const fence = line.match(/^\s*```\s*([\w-]*)\s*$/)
    if (fence) { if (code.length) { output.push(`<pre><code class="language-${codeLang}">${escapeHtml(code.join('\n'))}</code></pre>`); code = []; codeLang = '' } else { flushParagraph(); flushList(); flushQuote(); codeLang = fence[1] || 'text'; code = []; } continue }
    if (code.length || codeLang) { code.push(line); continue }
    if (!line.trim()) { flushParagraph(); flushList(); flushQuote(); continue }
    const heading = line.match(/^(#{1,6})\s+(.+?)\s*#*$/)
    if (heading) { flushParagraph(); flushList(); flushQuote(); const level = heading[1].length; const text = heading[2]; output.push(`<h${level} id="${slugify(text)}">${renderInline(text)}</h${level}>`); continue }
    const quoteLine = line.match(/^\s*>\s?(.*)$/)
    if (quoteLine) { flushParagraph(); flushList(); quote.push(quoteLine[1]); continue }
    const item = line.match(/^\s*([-*+] |\d+[.)] )(.*)$/)
    if (item) { flushParagraph(); flushQuote(); const isOrdered = /^\d/.test(item[1]); if (list.length && ordered !== isOrdered) flushList(); ordered = isOrdered; list.push(`<li>${renderInline(item[2])}</li>`); continue }
    flushList(); flushQuote(); paragraph.push(line)
  }
  if (code.length || codeLang) output.push(`<pre><code class="language-${codeLang}">${escapeHtml(code.join('\n'))}</code></pre>`)
  flushParagraph(); flushList(); flushQuote(); return output.join('')
}

function slugify(value: string) {
  return value.trim().replace(/\s+/g, '-')
}

const renderedContent = computed(() => renderMarkdown(article.value?.content || ''))

async function load() {
  loading.value = true
  article.value = null
  try {
    article.value = await getArticleDetail(articleId.value)
    await nextTick()
    document.querySelectorAll<HTMLElement>('.markdown-body pre').forEach((block) => {
      block.addEventListener('click', () => copyCode(block))
    })
    document.querySelectorAll<HTMLImageElement>('.markdown-body img').forEach((image) => {
      image.addEventListener('click', () => {
        previewImage.value = image.src
      })
    })
  } catch {
    ElMessage.error('文章不存在或已下线')
    router.replace({ name: 'NotFound' })
  } finally {
    loading.value = false
  }
}

async function copyCode(block: HTMLElement) {
  const code = block.querySelector('code')?.textContent || ''
  if (!code) return
  await navigator.clipboard.writeText(code)
  copying.value = true
  ElMessage.success('代码已复制')
  window.setTimeout(() => {
    copying.value = false
  }, 1200)
}

function scrollToAnchor(anchor: string) {
  document.getElementById(anchor)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

watch(articleId, load, { immediate: true })
</script>

<template>
  <section class="article-detail-page">
    <div v-loading="loading" class="article-layout">
      <article v-if="article" class="article-card blog-card">
        <header class="article-header">
          <button class="back-button" type="button" @click="router.back()">← 返回</button>
          <p class="eyebrow">ARTICLE</p>
          <h1>{{ article.title }}</h1>
          <div class="meta">
            <span>{{ article.categoryName }}</span
            ><span>{{ article.publishedAt }}</span
            ><span>阅读 {{ article.viewCount }}</span
            ><span>评论 {{ article.commentCount }}</span>
          </div>
        </header>
        <img v-if="article.cover" class="cover" :src="article.cover" :alt="article.title" />
        <div class="article-body-wrap">
          <aside v-if="article.toc?.length" class="toc">
            <h2>目录</h2>
            <button
              v-for="item in article.toc"
              :key="item.anchor"
              type="button"
              :class="`level-${item.level}`"
              @click="scrollToAnchor(item.anchor)"
            >
              {{ item.text }}
            </button>
          </aside>
          <div class="markdown-body" v-html="renderedContent" />
        </div>
        <div class="article-actions">
          <LikeButton :target-type="1" :target-id="article.id" :initial-count="article.likeCount" />
        </div>
        <nav class="article-nav">
          <button
            v-if="article.prevArticle"
            type="button"
            @click="router.push(`/articles/${article.prevArticle.id}`)"
          >
            <small>上一篇</small><span>{{ article.prevArticle.title }}</span></button
          ><button
            v-if="article.nextArticle"
            type="button"
            @click="router.push(`/articles/${article.nextArticle.id}`)"
          >
            <small>下一篇</small><span>{{ article.nextArticle.title }}</span>
          </button>
        </nav>
        <CommentSection :target-type="1" :target-id="article.id" />
      </article>
      <el-empty v-else-if="!loading" description="文章不存在" />
    </div>
    <span v-if="copying" class="copy-status">已复制</span>
    <div v-if="previewImage" class="image-preview" @click="previewImage = ''">
      <img :src="previewImage" alt="文章图片预览" />
    </div>
  </section>
</template>

<style scoped lang="scss">
.article-layout {
  max-width: 980px;
  margin: 0 auto;
}
.article-card {
  padding: clamp(18px, 4vw, 42px);
}
.article-header {
  position: relative;
}
.back-button {
  border: 0;
  background: transparent;
  color: var(--blog-muted);
  padding: 0;
  margin-bottom: 18px;
  cursor: pointer;
}
.back-button:hover {
  color: var(--blog-primary);
}
.eyebrow {
  margin: 0 0 5px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.8px;
  font-weight: 700;
}
.article-header h1 {
  margin: 0 0 12px;
  font-size: clamp(28px, 5vw, 42px);
  line-height: 1.25;
}
.meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  color: var(--blog-muted);
  font-size: 12px;
}
.cover {
  width: 100%;
  max-height: 420px;
  object-fit: cover;
  border-radius: 6px;
  margin: 24px 0;
}
.article-body-wrap {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 190px;
  gap: 28px;
}
.toc {
  position: sticky;
  top: 88px;
  align-self: start;
  border-left: 1px solid var(--blog-border);
  padding-left: 14px;
}
.toc h2 {
  margin: 0 0 10px;
  font-size: 13px;
  color: var(--blog-muted);
}
.toc button {
  display: block;
  width: 100%;
  border: 0;
  background: transparent;
  text-align: left;
  color: var(--blog-muted);
  font-size: 12px;
  padding: 4px 0;
  cursor: pointer;
}
.toc button:hover {
  color: var(--blog-primary);
}
.toc .level-3 {
  padding-left: 12px;
}
.markdown-body {
  min-width: 0;
  line-height: 1.9;
  font-size: 16px;
  word-break: break-word;
}
.markdown-body :deep(h1),
.markdown-body :deep(h2),
.markdown-body :deep(h3) {
  scroll-margin-top: 84px;
  line-height: 1.35;
  margin: 1.6em 0 0.6em;
}
.markdown-body :deep(p) {
  margin: 0 0 1em;
}
.markdown-body :deep(pre) {
  position: relative;
  overflow: auto;
  padding: 16px;
  border-radius: 6px;
  background: #17212b;
  color: #e8edf3;
  cursor: pointer;
}
.markdown-body :deep(code) {
  padding: 2px 5px;
  border-radius: 4px;
  background: #eef2f6;
  font-size: 0.9em;
}
.markdown-body :deep(pre code) {
  padding: 0;
  background: none;
  color: inherit;
}
.markdown-body :deep(blockquote) {
  margin: 1em 0;
  padding: 8px 14px;
  border-left: 3px solid var(--blog-accent);
  color: var(--blog-muted);
  background: #fff8f4;
}
.markdown-body :deep(ul),
.markdown-body :deep(ol) { margin: 0 0 1em; padding-left: 1.5em; }
.markdown-body :deep(li) { margin: .35em 0; }
.markdown-body :deep(a) { color: var(--blog-primary); text-decoration: underline; text-underline-offset: 3px; }
.markdown-body :deep(img) { display: block; max-width: 100%; margin: 1em auto; border-radius: 8px; cursor: zoom-in; }
.markdown-body :deep(hr) { margin: 2em 0; border: 0; border-top: 1px solid var(--blog-border); }
.markdown-body :deep(table) { width: 100%; margin: 1em 0; border-collapse: collapse; font-size: .92em; }
.markdown-body :deep(th), .markdown-body :deep(td) { padding: 8px 10px; border: 1px solid var(--blog-border); text-align: left; }
.markdown-body :deep(th) { background: color-mix(in srgb, var(--blog-primary) 10%, transparent); }
.article-actions {
  display: flex;
  justify-content: center;
  margin-top: 26px;
}
.article-nav {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-top: 28px;
}
.article-nav button {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding: 13px;
  border: 1px solid var(--blog-border);
  border-radius: 6px;
  background: transparent;
  text-align: left;
  cursor: pointer;
}
.article-nav button:last-child {
  text-align: right;
}
.article-nav button:hover {
  border-color: var(--blog-primary);
}
.article-nav small {
  color: var(--blog-muted);
}
.article-nav span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.copy-status {
  position: fixed;
  right: 24px;
  bottom: 24px;
  padding: 7px 12px;
  border-radius: 5px;
  color: #fff;
  background: var(--blog-primary);
  font-size: 12px;
}
@media (max-width: 800px) {
  .article-body-wrap {
    display: block;
  }
  .toc {
    position: static;
    margin-bottom: 22px;
    padding: 12px;
    border: 1px solid var(--blog-border);
    border-radius: 6px;
  }
  .toc button {
    display: inline-block;
    width: auto;
    margin-right: 14px;
  }
  .toc .level-3 {
    padding-left: 0;
  }
}
</style>
