<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { searchArticles } from '@/api/search'
import ArticleCard from '@/components/article/ArticleCard.vue'
const route = useRoute(); const router = useRouter(); const keyword = ref(String(route.query.q || '')); const records = ref<Awaited<ReturnType<typeof searchArticles>>['records']>([]); const loading = ref(false); const searched = ref(false)
async function search() { if (!keyword.value.trim()) return; loading.value = true; searched.value = true; router.replace({ path: '/search', query: { q: keyword.value.trim() } }); try { records.value = (await searchArticles({ keyword: keyword.value.trim(), page: 1, pageSize: 20 })).records } finally { loading.value = false } }
onMounted(() => { if (keyword.value) search() })
</script>
<template><section class="search-page"><header class="page-heading"><p class="eyebrow">SEARCH</p><h1>搜索</h1><div class="search-box"><input v-model="keyword" placeholder="输入关键词" @keyup.enter="search" /><button type="button" @click="search">搜索</button></div></header><div v-loading="loading" class="results"><button v-for="item in records" :key="item.id" type="button" class="result-link" @click="router.push(`/articles/${item.id}`)"><ArticleCard :article="item" /></button><p v-if="searched && !loading && !records.length" class="empty">没有找到相关文章</p></div></section></template>
<style scoped>.page-heading{margin-bottom:22px}.eyebrow{margin:0 0 4px;color:var(--blog-primary);font-size:11px;letter-spacing:2px;font-weight:700}h1{margin:0 0 14px;font-size:34px}.search-box{display:flex;gap:8px;max-width:620px}.search-box input{flex:1;padding:10px;border:1px solid var(--blog-border);border-radius:7px;background:var(--blog-card-bg);color:var(--blog-text)}.search-box button{padding:0 16px;border:0;border-radius:7px;background:var(--blog-primary);color:#fff;cursor:pointer}.results{display:flex;flex-direction:column;gap:14px}.result-link{padding:0;border:0;background:none;text-align:left;cursor:pointer}.empty{text-align:center;color:var(--blog-muted)}</style>
