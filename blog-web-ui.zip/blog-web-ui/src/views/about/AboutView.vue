<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getAboutProfile, type AboutProfile, type Skill } from '@/api/about'

const about = ref<AboutProfile | null>(null)
const loading = ref(false)

const skillGroups = computed(() => {
  const groups = new Map<string, Skill[]>()
  for (const skill of about.value?.skills || []) {
    const category = skill.category || '其他'
    if (!groups.has(category)) groups.set(category, [])
    groups.get(category)?.push(skill)
  }
  return [...groups.entries()]
})

async function load() {
  loading.value = true
  try {
    about.value = await getAboutProfile()
  } catch {
    ElMessage.error('关于我信息加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <section class="about-page">
    <header class="page-heading">
      <p class="eyebrow">ABOUT</p>
      <h1>关于我</h1>
      <p class="subtitle">持续学习，持续构建，也持续记录。</p>
    </header>

    <div v-loading="loading" class="about-content">
      <template v-if="about">
        <section class="profile-card blog-card">
          <div class="profile-head">
            <el-avatar :src="about.avatar || undefined" :size="86" :alt="about.nickname">{{
              about.nickname?.slice(0, 1)
            }}</el-avatar>
            <div>
              <h2>{{ about.nickname }}</h2>
              <p v-if="about.signature">{{ about.signature }}</p>
            </div>
          </div>
          <p class="intro">{{ about.intro || '暂无个人简介' }}</p>
        </section>

        <section class="skills-section">
          <div class="section-heading">
            <h2>技能树</h2>
            <span>Skills</span>
          </div>
          <div class="skill-groups">
            <div
              v-for="[category, skills] in skillGroups"
              :key="category"
              class="skill-group blog-card"
            >
              <h3>{{ category }}</h3>
              <div v-for="skill in skills" :key="`${category}-${skill.name}`" class="skill-row">
                <div class="skill-label">
                  <span>{{ skill.name }}</span
                  ><strong>{{ Math.max(0, Math.min(100, skill.level || 0)) }}%</strong>
                </div>
                <el-progress
                  :percentage="Math.max(0, Math.min(100, skill.level || 0))"
                  :show-text="false"
                  :stroke-width="8"
                />
              </div>
            </div>
          </div>
          <el-empty v-if="!skillGroups.length" description="暂无技能信息" />
        </section>

        <section class="timeline-section">
          <div class="section-heading">
            <h2>履历</h2>
            <span>Milestones</span>
          </div>
          <el-timeline
            ><el-timeline-item
              v-for="(milestone, index) in about.milestones"
              :key="`${milestone.year}-${milestone.title}-${index}`"
              :timestamp="milestone.year"
              placement="top"
              ><div class="milestone">
                <h3>{{ milestone.title }}</h3>
                <p v-if="milestone.description">{{ milestone.description }}</p>
              </div></el-timeline-item
            ></el-timeline
          ><el-empty v-if="!about.milestones?.length" description="暂无履历信息" />
        </section>
      </template>
      <el-empty v-else-if="!loading" description="暂无关于我信息" />
    </div>
  </section>
</template>

<style scoped lang="scss">
.page-heading {
  margin-bottom: 26px;
}
.eyebrow {
  margin: 0 0 4px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.8px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: clamp(24px, 4vw, 34px);
}
.subtitle {
  margin: 8px 0 0;
  color: var(--blog-muted);
}
.about-content {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.profile-card {
  padding: 28px;
}
.profile-head {
  display: flex;
  align-items: center;
  gap: 18px;
}
.profile-head h2 {
  margin: 0;
  font-size: 26px;
}
.profile-head p {
  margin: 5px 0 0;
  color: var(--blog-muted);
}
.intro {
  margin: 22px 0 0;
  white-space: pre-wrap;
  line-height: 1.85;
}
.section-heading {
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin-bottom: 14px;
}
.section-heading h2 {
  margin: 0;
  font-size: 20px;
}
.section-heading span {
  color: var(--blog-muted);
  font-size: 12px;
  letter-spacing: 1px;
}
.skill-groups {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 14px;
}
.skill-group {
  padding: 18px;
}
.skill-group h3 {
  margin: 0 0 16px;
  font-size: 15px;
}
.skill-row {
  margin-top: 13px;
}
.skill-label {
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  font-size: 13px;
}
.skill-label strong {
  color: var(--blog-primary);
  font-size: 12px;
}
.timeline-section {
  max-width: 760px;
}
.milestone h3 {
  margin: 0;
  font-size: 16px;
}
.milestone p {
  margin: 5px 0 0;
  color: var(--blog-muted);
  white-space: pre-wrap;
}
@media (max-width: 600px) {
  .profile-card {
    padding: 20px;
  }
  .profile-head h2 {
    font-size: 22px;
  }
  .skill-groups {
    grid-template-columns: 1fr;
  }
}
</style>
