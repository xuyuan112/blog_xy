<script setup lang="ts">
import { useRouter } from 'vue-router'
import BaseCard from '@/components/BaseCard.vue'
const router = useRouter()
</script>
<template>
  <BaseCard class="not-found">
    <p class="code">404</p><h1>页面不存在</h1>
    <p>你访问的内容可能已被删除、下线或地址有误。</p>
    <div class="actions"><el-button type="primary" @click="router.push('/')">返回首页</el-button><el-button @click="router.back()">返回上一页</el-button></div>
  </BaseCard>
</template>
<style scoped>
.not-found{max-width:640px;margin:12vh auto;padding:clamp(32px,8vw,72px);text-align:center}.code{margin:0;color:var(--blog-primary);font-size:clamp(64px,14vw,120px);font-weight:800;line-height:1}h1{margin:18px 0 10px;font-size:28px}.not-found>p:not(.code){color:var(--blog-muted)}.actions{display:flex;justify-content:center;gap:10px;margin-top:28px}
</style>
