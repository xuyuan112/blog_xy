<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import {
  getThoughtDetail,
  getThoughtPage,
  type ArticleDetail,
  type ArticleListItem
} from '@/api/article'
import LikeButton from '@/components/LikeButton.vue'

const route = useRoute()
const router = useRouter()
const thoughts = ref<ArticleListItem[]>([])
const detail = ref<ArticleDetail | null>(null)
const page = ref(1)
const total = ref(0)
const loading = ref(false)
const keyword = ref('')
const readingMode = ref(false)
const detailId = computed(() => Number(route.params.id) || 0)

async function loadList() {
  loading.value = true
  try {
    const result = await getThoughtPage({
      page: page.value,
      pageSize: 10,
      keyword: keyword.value || undefined
    })
    thoughts.value = result.records
    total.value = result.total
  } catch {
    ElMessage.error('杂谈加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

async function loadDetail() {
  loading.value = true
  try {
    detail.value = await getThoughtDetail(detailId.value)
  } catch {
    ElMessage.error('杂谈不存在或未发布')
    router.replace('/thoughts')
  } finally {
    loading.value = false
  }
}

function selectPage(value: number) {
  page.value = value
  loadList()
}

function openDetail(id: number) {
  router.push(`/thoughts/${id}`)
}

watch(
  detailId,
  (id) => {
    if (id) loadDetail()
    else loadList()
  },
  { immediate: true }
)

onMounted(() => {
  readingMode.value = sessionStorage.getItem('thought-reading-mode') === 'true'
})

watch(readingMode, (value) => {
  sessionStorage.setItem('thought-reading-mode', String(value))
})
</script>

<template>
  <section class="thought-page" :class="{ 'reading-mode': readingMode }">
    <header class="page-heading">
      <div>
        <p class="eyebrow">THOUGHTS</p>
        <h1>{{ detailId ? detail?.title || '杂谈详情' : '杂谈' }}</h1>
        <p class="subtitle">慢一点阅读，给思想留出回响的空间。</p>
      </div>
      <el-button v-if="detailId" text @click="router.push('/thoughts')">返回杂谈</el-button>
    </header>

    <article v-if="detailId" v-loading="loading" class="thought-detail blog-card">
      <div class="detail-meta">
        <span>{{ detail?.publishedAt }}</span
        ><span>阅读 {{ detail?.viewCount || 0 }}</span
        ><button type="button" class="mode-button" @click="readingMode = !readingMode">
          {{ readingMode ? '退出阅读模式' : '沉浸阅读' }}
        </button>
      </div>
      <p v-if="detail?.summary" class="lead">{{ detail.summary }}</p>
      <LikeButton
        v-if="detail"
        :target-type="1"
        :target-id="detail.id"
        :initial-count="detail.likeCount"
      />
      <pre v-if="detail" class="markdown-content">{{ detail.content }}</pre>
    </article>

    <div v-else class="thought-list-wrap">
      <div class="filter-bar blog-card">
        <el-input
          v-model="keyword"
          clearable
          placeholder="搜索杂谈"
          @keyup.enter="loadList"
          @clear="loadList"
          ><template #append><el-button @click="loadList">搜索</el-button></template></el-input
        >
      </div>
      <div v-loading="loading" class="thought-list">
        <article
          v-for="item in thoughts"
          :key="item.id"
          class="thought-card blog-card"
          @click="openDetail(item.id)"
        >
          <div v-if="item.cover" class="cover-wrap">
            <img :src="item.cover" :alt="item.title" loading="lazy" />
          </div>
          <div class="card-body">
            <p class="card-type">随笔</p>
            <h2>{{ item.title }}</h2>
            <p class="summary">{{ item.summary || '暂无摘要' }}</p>
            <div class="meta">
              <span>阅读 {{ item.viewCount }}</span
              ><time>{{ item.publishedAt }}</time>
            </div>
          </div>
        </article>
        <el-empty v-if="!loading && !thoughts.length" description="暂无杂谈" />
      </div>
      <el-pagination
        v-if="total > 10"
        layout="prev, pager, next"
        :current-page="page"
        :page-size="10"
        :total="total"
        @current-change="selectPage"
      />
    </div>
  </section>
</template>

<style scoped lang="scss">
.page-heading {
  display: flex;
  justify-content: space-between;
  align-items: end;
  margin-bottom: 24px;
}
.eyebrow {
  margin: 0 0 4px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1.8px;
  font-weight: 700;
}
h1 {
  margin: 0;
  font-size: clamp(24px, 4vw, 34px);
}
.subtitle {
  margin: 8px 0 0;
  color: var(--blog-muted);
}
.thought-list-wrap {
  max-width: 820px;
}
.filter-bar {
  margin-bottom: 18px;
}
.thought-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.thought-card {
  display: flex;
  gap: 18px;
  cursor: pointer;
  transition:
    transform 0.2s,
    box-shadow 0.2s;
}
.thought-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px #17212b14;
}
.cover-wrap {
  width: 180px;
  flex: none;
}
.cover-wrap img {
  width: 100%;
  height: 130px;
  object-fit: cover;
  border-radius: 5px;
}
.card-body {
  min-width: 0;
  flex: 1;
}
.card-type {
  margin: 0 0 3px;
  color: var(--blog-primary);
  font-size: 11px;
  letter-spacing: 1px;
}
.card-body h2 {
  margin: 0 0 7px;
  font-size: 19px;
}
.summary {
  margin: 0 0 14px;
  color: var(--blog-muted);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.meta,
.detail-meta {
  display: flex;
  gap: 14px;
  align-items: center;
  color: var(--blog-muted);
  font-size: 12px;
}
.meta time {
  margin-left: auto;
}
.el-pagination {
  justify-content: center;
  margin-top: 24px;
}
.thought-detail {
  max-width: 820px;
}
.detail-meta {
  padding-bottom: 14px;
  border-bottom: 1px solid var(--blog-border);
}
.mode-button {
  margin-left: auto;
  border: 1px solid var(--blog-border);
  background: transparent;
  border-radius: 5px;
  padding: 4px 9px;
  color: var(--blog-muted);
  cursor: pointer;
}
.mode-button:hover {
  color: var(--blog-primary);
  border-color: var(--blog-primary);
}
.lead {
  margin: 22px 0;
  padding-left: 14px;
  border-left: 3px solid var(--blog-accent);
  color: var(--blog-muted);
}
.markdown-content {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  font: inherit;
  line-height: 1.9;
  background: transparent;
  color: inherit;
}
.reading-mode {
  --blog-text: #3b3b32;
  background: #f5f1e8;
  min-height: calc(100vh - 120px);
}
.reading-mode .thought-detail {
  background: #fbf8f0;
  border-color: #e6dfd0;
}
.reading-mode .markdown-content {
  font-size: 17px;
  line-height: 2.05;
}
@media (max-width: 600px) {
  .thought-card {
    display: block;
  }
  .cover-wrap {
    width: 100%;
    margin-bottom: 14px;
  }
  .cover-wrap img {
    height: 180px;
  }
  .meta time {
    margin-left: auto;
  }
  .thought-detail {
    padding: 16px;
  }
}
</style>
