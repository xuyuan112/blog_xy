import { computed, ref } from 'vue'
export function usePagination(pageSize = 10) { const page = ref(1); const total = ref(0); const hasMore = computed(() => page.value * pageSize < total.value); const reset = () => { page.value = 1 }; const next = () => { if (hasMore.value) page.value += 1 }; return { page, total, hasMore, reset, next, pageSize } }
