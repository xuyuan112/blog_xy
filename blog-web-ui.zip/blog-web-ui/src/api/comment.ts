import { get, post } from '@/utils/request'
import type { PageResult } from '@/types/api'

export interface Comment {
  id: number
  targetType: number
  targetId: number
  content: string
  nickname: string
  avatar?: string
  createdAt: string
}

export function getCommentPage(params: {
  targetType: number
  targetId: number
  page?: number
  pageSize?: number
}) {
  return get<PageResult<Comment>>('/comments', params)
}

export function createComment(data: {
  targetType: number
  targetId: number
  content: string
  nickname: string
  email?: string
  website?: string
}) {
  return post<{ id: number }>('/comments', data)
}
