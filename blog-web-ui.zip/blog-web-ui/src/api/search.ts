import { get } from '@/utils/request'
import type { PageQuery, PageResult } from '@/types/api'
import type { ArticleListItem } from '@/api/article'

export function searchArticles(params: PageQuery & { keyword: string }) {
  return get<PageResult<ArticleListItem>>('/search', params)
}
