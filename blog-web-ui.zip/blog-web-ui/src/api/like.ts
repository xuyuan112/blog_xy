import { post } from '@/utils/request'

export interface LikeToggleResult {
  targetId: number
  liked: boolean
  likeCount: number
}

export function toggleLike(targetType: number, targetId: number) {
  return post<LikeToggleResult>('/likes/toggle', { targetType, targetId })
}
