import { request, authService } from '@/utils/request'

export interface UserInfo {
  userId: number
  username: string
  nickname: string
  avatar: string | null
  email: string | null
}

export interface TokenResult {
  accessToken: string
  refreshToken: string
  expiresIn: number
  tokenType: 'Bearer'
  userInfo?: UserInfo
}

export function register(data: {
  username: string
  password: string
  nickname: string
  email?: string
}) {
  return request<TokenResult>(authService, { method: 'post', url: '/app/auth/register', data })
}

export function login(data: { username: string; password: string }) {
  return request<TokenResult>(authService, { method: 'post', url: '/app/auth/login', data })
}

export function refreshToken(refreshToken: string) {
  return request<TokenResult>(authService, {
    method: 'post',
    url: '/app/auth/refresh',
    data: { refreshToken }
  })
}

export function getUserInfo() {
  return request<UserInfo>(authService, { method: 'get', url: '/app/auth/userinfo' })
}

export function logout() {
  return request<void>(authService, { method: 'post', url: '/app/auth/logout' })
}

export function changePassword(data: { oldPassword: string; newPassword: string }) {
  return request<void>(authService, { method: 'put', url: '/app/auth/password', data })
}
