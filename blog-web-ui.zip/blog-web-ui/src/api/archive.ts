import { get } from '@/utils/request'

export interface Category {
  id: number
  name: string
  description?: string
  articleCount: number
}

export interface Tag {
  id: number
  name: string
  color?: string
  weight?: number
  articleCount: number
}

export interface TimelineYear {
  year: string
  months: { month: string; articles: { id: number; title: string; publishedAt: string }[] }[]
}

export function getCategories() {
  return get<Category[]>('/categories')
}

export function getTags() {
  return get<Tag[]>('/tags')
}

export function getTimeline() {
  return get<TimelineYear[]>('/archives/timeline')
}
