import { get, post } from '@/utils/request'
import type { PageQuery, PageResult } from '@/types/api'

/** 文章列表项 */
export interface ArticleListItem {
  id: number
  title: string
  cover: string
  summary: string
  categoryId: number
  categoryName: string
  tags: { id: number; name: string }[]
  viewCount: number
  commentCount: number
  likeCount: number
  type: number
  isTop: boolean
  publishedAt: string
}

/** 文章详情 */
export interface ArticleDetail extends ArticleListItem {
  content: string
  toc: { level: number; text: string; anchor: string }[]
  prevArticle: { id: number; title: string } | null
  nextArticle: { id: number; title: string } | null
  updatedAt: string
}

export function getArticlePage(
  params: PageQuery & { keyword?: string; categoryId?: number; tagId?: number }
) {
  return get<PageResult<ArticleListItem>>('/articles', params)
}

export function getArticleDetail(id: number) {
  return get<ArticleDetail>(`/articles/${id}`)
}

export function getHotArticles(limit = 5) {
  return get<{ id: number; title: string; viewCount: number }[]>('/articles/hot', { limit })
}

export function getThoughtPage(params: PageQuery & { keyword?: string }) {
  return get<PageResult<ArticleListItem>>('/thoughts', params)
}

export function getThoughtDetail(id: number) {
  return get<ArticleDetail>(`/thoughts/${id}`)
}

export { post }
