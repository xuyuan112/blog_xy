import { get } from '@/utils/request'

export interface Moment {
  id: number
  content: string
  images: string[]
  location?: string
  mood?: string
  likeCount: number
  commentCount: number
  createdAt: string
}

export function getMomentPage(params: { page?: number; pageSize?: number }) {
  return get<{ records: Moment[]; total: number; page: number; pageSize: number; pages: number }>(
    '/moments',
    params
  )
}

export function getMomentDetail(id: number) {
  return get<Moment>(`/moments/${id}`)
}
