import { get } from '@/utils/request'

export interface Gallery {
  id: number
  name: string
  description?: string
  cover: string
  photoCount: number
  shootDate?: string
  createdAt: string
}

export interface Photo {
  id: number
  galleryId: number
  original: string
  thumbnail: string
  shootTime?: string
  exif?: {
    cameraModel?: string
    iso?: number
    shutterSpeed?: string
    aperture?: string
    focalLength?: string
    lensModel?: string
  }
}

export function getGalleryPage(params: { page?: number; pageSize?: number; keyword?: string }) {
  return get<{ records: Gallery[]; total: number; page: number; pageSize: number; pages: number }>(
    '/galleries',
    params
  )
}

export function getGalleryDetail(id: number) {
  return get<GalleryDetail>(`/galleries/${id}`)
}

export interface GalleryDetail {
  id: number
  name: string
  description?: string
  shootDate?: string
  photos: Photo[]
}

export function getPhotoDetail(id: number) {
  return get<Photo>(`/photos/${id}`)
}
