import { get } from '@/utils/request'

export interface Skill {
  name: string
  level: number
  category?: string
}

export interface Milestone {
  year: string
  title: string
  description?: string
}

export interface AboutProfile {
  nickname: string
  avatar: string | null
  signature?: string
  intro: string
  skills: Skill[]
  milestones: Milestone[]
}

export function getAboutProfile() {
  return get<AboutProfile>('/about')
}
