import { get, post } from '@/utils/request'

export interface Notice {
  id: number
  content: string
  updatedAt: string
}
export interface Word {
  content: string
  source?: string
}
export interface Weather {
  city: string
  temp: string
  weather: string
  icon: string
}
export interface Schedule {
  id: number
  title: string
  targetTime: string
  type: string
}

export const getNotice = () => get<Notice>('/site/notice')
export const getRandomWord = () => get<Word>('/site/words/random')
export const getWeather = () => get<Weather>('/site/weather')
export const getSchedules = () => get<Schedule[]>('/site/schedules')

export interface Friend {
  id: number
  name: string
  avatar: string
  description?: string
  url: string
}

export interface FriendGroup {
  name: string
  friends: Friend[]
}

export function getFriendList(group?: string) {
  return get<{ total: number; groups: FriendGroup[] }>('/friends', { group })
}

export function getRandomFriend() {
  return get<{ id: number; name: string; url: string }>('/friends/random')
}

export function applyFriend(data: {
  name: string
  url: string
  avatar?: string
  description?: string
  email: string
  group?: string
}) {
  return post('/friends/apply', data)
}

export function getAbout() {
  return get<{
    nickname: string
    avatar: string
    signature?: string
    intro: string
    skills: { name: string; level: number; category: string }[]
    milestones: { year: string; title: string; description?: string }[]
  }>('/about')
}
