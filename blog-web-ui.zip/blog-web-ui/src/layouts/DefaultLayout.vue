<script setup lang="ts">
import { RouterView } from "vue-router"
import SiteBanner from "@/components/site/SiteBanner.vue"
import SiteNavbar from "@/components/site/SiteNavbar.vue"
import SiteFooter from "@/components/site/SiteFooter.vue"
import FloatingControls from "@/components/site/FloatingControls.vue"
import SidebarColumn from "@/components/sidebar/SidebarColumn.vue"
</script>

<template>
  <div class="site-shell">
    <SiteBanner />
    <SiteNavbar />
    <div class="page-grid">
      <SidebarColumn />
      <main class="main-content"><RouterView /></main>
      <aside class="right-rail"><section class="rail-card glass-card"><h2>站点统计</h2><div class="stat-row"><span>文章</span><b>占位</b></div><div class="stat-row"><span>分类</span><b>占位</b></div><div class="stat-row"><span>标签</span><b>占位</b></div><div class="stat-row"><span>运行天数</span><b>占位</b></div></section><section class="rail-card glass-card"><h2>快速入口</h2><p class="muted">站点 Widget 待接入后端接口</p></section></aside>
    </div>
    <FloatingControls />
    <SiteFooter />
  </div>
</template>
